#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void viderBuffer(){
  int c;
  while ((c = getchar()) != '\n' && c != EOF);
}

int main(){
  
}
