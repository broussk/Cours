#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#define TAILLE 50

int main(){

  return 0;
}
