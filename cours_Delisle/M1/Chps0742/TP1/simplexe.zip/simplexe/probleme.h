#include "types.h"

int lireProbleme(char *, prob_t *);

void afficherProbleme(prob_t);

void libererMemoireProbleme(prob_t);
