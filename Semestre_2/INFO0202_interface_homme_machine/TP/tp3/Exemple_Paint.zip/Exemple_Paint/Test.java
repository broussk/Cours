public class Test
{
    public static void main(String[] args)
    {
	MyJFrame myJFrame= new MyJFrame();
    }
}
