import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Graphics;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class MyJLabel extends JLabel
{
    private static final long serialVersionUID = 111111111111L;
    
    public MyJLabel(int value)
    {
	this.setHorizontalAlignment(SwingConstants.CENTER);
	this.setVerticalAlignment(SwingConstants.CENTER);
	this.setText(Integer.toString(value));

	this.addMouseListener( new MouseListener() 
	    {
		public void mouseClicked(MouseEvent e)
		{
		    if(e.getButton()==MouseEvent.BUTTON1)
			{
			    String value= MyJLabel.this.getText();
			    int intValue=Integer.parseInt(value);
			    MyJLabel.this.setText(Integer.toString(intValue-1));
			}
		}
		public void mouseExited(MouseEvent e){}
		public void mouseEntered(MouseEvent e){}
		public void mouseReleased(MouseEvent e){}
		public void mousePressed(MouseEvent e){}
	    });
    }			
				

    public void paintComponent(Graphics g)
    {
	super.paintComponent(g);
	g.drawOval(0,0,this.getWidth(),this.getHeight());
    }
}
