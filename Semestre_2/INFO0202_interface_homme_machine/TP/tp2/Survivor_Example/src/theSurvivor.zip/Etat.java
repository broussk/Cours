package theSurvivor;

public enum Etat{NON_VISITEE, VISITEE, RIMBO}
