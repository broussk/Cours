#ifndef _BIGSIGNEDINTEGER_H
#define _BIGSIGNEDINTEGER_H
#include <iostream>
#include <cstdlib>
#include <string>
#include "BigInteger.h"
//#pragma once

/// @brief This class exposes signed integer arithmetic support for all
/// 	   basic arithmetic operations.
class BigSignedInteger : public BigInteger {
protected:
	int8_t _sign;
public:
	/// Default constructor (positive zero).
	inline BigSignedInteger() : BigInteger(), _sign(1) {};
	/// Constructor with digits allocation (positive zero).
	///  @param ndigits	number of digits to allocate.
	inline BigSignedInteger(digitsize_t ndigits) : BigInteger(ndigits), _sign(1) {};
	/// Constructor with bits allocation (positive zero).
	/// @param nbits	number of bits to allocate.
	inline BigSignedInteger(bitsize_t nbits) : BigInteger(nbits), _sign(1) {};
	/// Copy constructor from a BigInteger.
	/// @param d	BigInteger to construct from.
	inline BigSignedInteger(const BigInteger &d) : BigInteger(d), _sign(1) {};
	/// Move constructor from a BigInteger.
	/// @param d	BigInteger to move from.
	inline BigSignedInteger(BigInteger &&d) : BigInteger(std::move(d)), _sign(1) {};
	/// Destructor
	inline ~BigSignedInteger() {};
	/// return the BigInteger from the BigSignedInteger.
	/// @return	the BigInteger.
	inline BigInteger &integer() { return *this; }
	/// return the sign of the BigSignedInteger.
	/// @return	the sign.
	inline int8_t sign() const { return _sign; }
	/// set a BigSignedInteger as a positive short integer
	/// @param value	the short integer to set from.
	inline int SetPositiveShort(digit_t value) { SetShort(value); _sign = +1; return _sign; }
	/// set a BigSignedInteger as a negative short integer
	/// @param value	the short integer to set from.
	/// @return	the sign.
	inline int SetNegativeShort(digit_t value) { SetShort(value); _sign = -1; return _sign; }
	/// compute the product of two BigSignedInteger.
	/// @param u	first BigSignedInteger
	/// @param v	second BigSignedInteger
	/// @return	the sign.
	inline int Multiply(const BigSignedInteger &u, const BigSignedInteger &v) {
		_sign = u._sign * v._sign;
		return BigInteger::Multiply(u, v);
	}
	/// compute the division of two BigSignedInteger. 
	/// @param u	first BigSignedInteger (numerator)
	/// @param v	second BigSignedInteger (denominator)
	/// @param r	remainder of the division (returned).
	/// @return	always return 0.
	inline int Divide(BigInteger &r, const BigSignedInteger &u, const BigSignedInteger &v) {
		_sign = u._sign * v._sign;
		int h = this->BigInteger::Divide(r, u, v);

	}
	/// add two BigSignedIntegers.
	/// @param u	first BigSignedInteger
	/// @param v	second BigSignedInteger
	/// @return	return should always be zero.
	inline int Add(const BigSignedInteger &u, const BigSignedInteger &v) {
		_sign = u._sign * v._sign;
		if (_sign > 0) return BigInteger::Add(u, v);
		else {
			int r = Compare(u, v);
			if (r == 0) return zero();
			else if (r < 0) {
				_sign = (v._sign > 0 ? +1 : -1);
				return BigInteger::Subtract(v, u);
			}
			else {
				_sign = (u._sign > 0 ? +1 : -1);
				return BigInteger::Subtract(u, v);
			}
		}
	}
	/// subtract two BigSignedIntegers.
	/// @param u	first BigSignedInteger
	/// @param v	second BigSignedInteger
	/// @return	return should always be zero.
	inline int Subtract(const BigSignedInteger &u, const BigSignedInteger &v) {
		_sign = u._sign * v._sign;
		if (_sign < 0) {
			_sign = u._sign;
			return BigInteger::Add(u, v);
		}
		else {
			int r = Compare(u, v);
			if (r == 0) return zero();
			else if (r < 0) { // v>u
				_sign = (v._sign > 0 ? -1 : +1);
				return BigInteger::Subtract(v, u);
			}
			else { // u>v
				_sign = (u._sign > 0 ? +1 : -1);
				return BigInteger::Subtract(u, v);
			}
		}
	}
	/// swap two BigSignedInteger.
	/// @param u	the BigSignedInteger to swap from.
	inline void swap(BigSignedInteger &u) {
		BigInteger::swap(u);
		std::swap(_sign, u._sign);
	}
	/// view a BigSignedInteger as a decimal.
	/// @param title  	label to use for this decimal.
	/// @param eol	  	(Optional) true to add a new line.
	/// @param stream	(Optional) the optional output stream.
	inline void viewDec(const char *title = nullptr, bool eol = true, std::ostream &stream = std::cout) const {
		std::string str;
		ConvToDecimal(str);
		if (title) stream << title << " ";
		stream << (_sign > 0 ? '+' : '-');
		size_t len = str.length() - 1;
		for (size_t i = 0; i <= len; i++) {
			if (str[i] != ' ') {
				stream << str[i];
				if ((i != len) && ((len - i) % 3 == 0)) stream << ".";
			}
		}
		if (eol) stream << "\n";
	}
	/// overloading the redirection of a BigSignedInteger in a stream.
	inline friend std::ostream & operator<<(std::ostream &stream, const BigSignedInteger &d) {
		d.viewDec(nullptr, false, stream);
		return stream;
	}
};

///=================================================================================================
/// construct a BigInteger from a BigSignedInteger u modulo a BigInteger v. 
/// The resulting BigInteger w is 0 <= w < v.
/// @param u	The BigSignedInteger to process.
/// @param v	The BigInteger to process.
/// @return	always return 0.
inline uint32_t BigInteger::Modulo(const BigSignedInteger &u, const BigInteger &v) {
	const BigInteger &uu = u;
	if (u.sign() > 0) Modulo(uu, v);
	else {
		BigInteger	m;
		m.Modulo(uu, v);
		Subtract(v, m);
	}
	AdjustSize();
	return 0;
}

#endif

