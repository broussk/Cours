#include <stdio.h>
#include <iostream>
#include <string>
#include <chrono>
#include "BigInteger.h"
#include "BigRandomInteger.h"
//#include "BigSignedInteger.h"
// static int debug = 0;

int main(void)
{
	BigInteger	u, v, r,  p, q1, r1, m1, q2, r2, m2;
	u.ConvFromDecimal("123456789112233445566778899");
	v.ConvFromDecimal("975312468");
	r.ConvFromDecimal("124689753");

	printf("Multiplication test:\n");
	u.viewDec("u =");
	v.viewDec("v =");
	r.viewDec("r =");
	p.Multiply(u, v);
	p.viewDec("p = u*v =");
	p.Add(p, r);
	p.viewDec("p = u*v + r =");

	printf("\nDivision cross test 1: q1 = p/u, r1 = p mod u\n");
	q1.Divide(r1, p, u);
	q1.viewDec("q1 =");
	r1.viewDec("r1 =");

	printf("\nProof:\n");
	m1.Multiply(q1,u);
	m1.viewDec("m1 = q1*u =");
	m1.Add(m1, r1);
	m1.viewDec("m1 = q1*u + r1 =");

	printf("\nDivision cross test 2: q2 = p/v, r2 = p mod v\n");
	q2.Divide(r2, p, v);
	q2.viewDec("q2 =");
	r2.viewDec("r2 =");

	printf("\nProof:\n");
	m2.Multiply(q2, v);
	m2.viewDec("m2 = q2*v =");
	m2.Add(m2, r2);
	m2.viewDec("m2 = q2*v + r2 =");

	BigInteger
		vv = BigRandomInteger(512_bits),
		v1 = BigRandomInteger(24_bits),
		v2 = BigRandomInteger(48_bits);
	vv.viewDec("Random 512 bits=");
	v1.viewDec("v1=Random 24 bits=");
	v2.viewDec("v2=Random 48 bits=");

	/*
	BigSignedInteger   w;
	w.Subtract(v1, v2);
	w.viewDec("v1-v2=");
	*/

	return 0;
}




