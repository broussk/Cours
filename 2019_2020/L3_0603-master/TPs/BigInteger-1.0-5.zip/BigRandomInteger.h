#ifndef _BIGRANDOMINTEGER_H
#define _BIGRANDOMINTEGER_H
// #pragma once
#include "BigType.h"
#include "BigInteger.h"

/***************************************************************************************
BigRandomInteger
****************************************************************************************/

class BigRandomInteger : public BigInteger {
public:
	BigRandomInteger(size_t ndigits);
	BigRandomInteger(bitsize_t nbits, bool force = true);
	BigRandomInteger(bytesize_t nbytes, bool force = true);
};

/*=================================================================================================*/
/// @brief Constructor of a random BigInteger with sz bits.
/// @param	sz   	The number of bits the random BigInteger must have.
/// @param	force	true to force the Most Significant Bit to be 1.
inline BigRandomInteger::BigRandomInteger(bitsize_t sz, bool force) : BigInteger() {
	size_t  nBits = sz % digit_t::BitSize;
	size_t  nDigits = sz / digit_t::BitSize + (nBits ? 1 : 0);
	digits.resize(nDigits);
	for (auto &x : digits) x = digit_t::random();
	// trimming the exceeding bits
	if (nBits != 0)
		digits[nDigits - 1] &= (digit_t::MaxValue >> (digit_t::BitSize - nBits));
	if (force) SetBit(sz - 1, 1);
}

/*=================================================================================================*/
/// @brief Constructor of a random BigInteger with sz bytes.
/// @param	sz   	The number of bytes the random BigInteger must have.
/// @param	force	true to force the Most Significant Byte to be non zero.
inline BigRandomInteger::BigRandomInteger(bytesize_t sz, bool force) : BigInteger() {
	size_t  nBytes = sz % digit_t::ByteSize;
	size_t  nDigits = sz / digit_t::ByteSize + (nBytes ? 1 : 0);
	digits.resize(nDigits);
	// random fill
	uint8_t  *data = reinterpret_cast<uint8_t*>(digits.data());
	for (size_t i = 0; i < sz; i++) data[i] = Byte::random();
	// trimming the exceeding bits
	if (force) data[sz - 1] = Byte::random_nz();
}

/*=================================================================================================*/
/// @brief Constructor of a random BigInteger with nz digits.
/// @param sz	the number of digits the BigInteger must have.
inline BigRandomInteger::BigRandomInteger(size_t sz) : BigInteger() {
	digits.resize(sz);
	for (auto &x : digits) x = digit_t::random();
}

#endif
