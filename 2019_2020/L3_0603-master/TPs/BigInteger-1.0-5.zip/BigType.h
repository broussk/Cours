// #pragma once
#ifndef _BIGTYPE_H
#define _BIGTYPE_H

#include <cstdint>
#include <random>

// for future 64bit compatibility
using size32_t = uint32_t;

/// @brief namespace for byte
namespace Byte {
	using type = uint8_t;								/// equivalent type
	extern std::mt19937	   					&&gen;		/// random engine
	extern std::uniform_int_distribution<short>	rnd;		/// return a random byte
	extern std::uniform_int_distribution<short>	rnd_nz;		/// return a random byte
	inline type random() { return type(rnd(gen)); }
	inline type random_nz() { return type(rnd_nz(gen)); }
}

/// @brief type representing an internal digit of a BigNumber.
struct digit_t {
	uint32_t	value;
	digit_t() : value(0) {}
	digit_t(uint32_t v) : value(v) {}
	void swap(digit_t &v) { std::swap(value, v.value); }
	operator uint32_t() const { return value; }
	explicit digit_t(unsigned long long n) : value(static_cast<uint32_t>(n)) {}
	inline size32_t MSB() const {
		uint32_t	v = value;
		size32_t	i = 0;
		while (v) { ++i; v >>= 1; }
		return i;
	}
	digit_t operator &=(const digit_t &v) { value &= v.value; return value; }	
	static const size_t ByteSize;
	static const size_t OctalSize;
	static const size_t BitSize;
	static const uint32_t MaxValue;
	static const uint32_t HiBitMask;
	/// raw type for constructing a digit from 4 bytes
	union raw {
		uint32_t  digit;
		uint8_t   byte[4];
	};
	/// return a random digit_t.
	/// @return	a random digit_t.
	static inline digit_t random() {
		raw    val;
		val.byte[0] = Byte::random();
		val.byte[1] = Byte::random();
		val.byte[2] = Byte::random();
		val.byte[3] = Byte::random();
		return val.digit;
	}
};

/// Integer divide round to the nearest highest integer
inline size_t DivUp(size_t u, size_t v) { return (u + v - 1) / v; }

/// @brief type representing a size measured in bits.
struct bitsize_t {
	size_t	value;
	operator size_t() const { return value; }
	bitsize_t() : value(0) {}
	explicit bitsize_t(unsigned long long n) : value(static_cast<size_t>(n)) {}
};
// allow to create a Bits value as 512_bits
inline bitsize_t operator"" _bits(unsigned long long n) { return bitsize_t(n); }

/// @brief type representing a size measured in bytes.
struct bytesize_t {
	size_t	value;
	operator size_t() const { return value; }
	explicit bytesize_t(unsigned long long n) : value(static_cast<size_t>(n)) {}
};
// allow to create a bytesize value as 13_bytes
inline bytesize_t operator"" _bytes(unsigned long long n) { return bytesize_t(n); }

/// @brief type representing a size measured in digits.
struct digitsize_t {
	size_t value;
	operator size_t() const { return value; }
	explicit digitsize_t(unsigned long long n) : value(static_cast<size_t>(n)) {}
	explicit digitsize_t(bitsize_t v)
		: value(DivUp(v.value, digit_t::BitSize)) {}
};
// allow to create a digitsize value as 13_digits
inline digitsize_t operator"" _digits(unsigned long long n) { return digitsize_t(n); }

#endif // _BIGTYPE_H