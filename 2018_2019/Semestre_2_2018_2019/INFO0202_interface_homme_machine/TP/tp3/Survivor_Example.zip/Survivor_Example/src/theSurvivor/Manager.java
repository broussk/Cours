package theSurvivor;

class Manager
{
    private Zone[][] island; 
    private int RimboRow;
    private int RimboColumn;

    public Manager(Zone[][] island)
    {
	int i,j;

	this.island=null;

	if(island != null)
	    {
		this.island=new Zone[island.length][island[0].length];
		for(i=0;i<this.island.length;i++)
		    {
			for(j=0;j<this.island[i].length;j++)
			    {
				this.island[i][j]=island[i][j];
			    }
		    }
	
		this.RimboRow=this.RimboColumn=0;
		init();
	    }

	
    }

    public String toString()
    {
	return "Manager of the behaviour of the system";
    }

    public void init()
    {
	island[RimboRow][RimboColumn].setText("");
	this.RimboRow=(int)(Math.random()*this.island.length);
	this.RimboColumn=(int)(Math.random()*this.island[0].length);
	this.island[this.RimboRow][this.RimboColumn].explore();
	this.island[this.RimboRow][this.RimboColumn].setText("R");
    }

    public boolean exploration(String direction)
    {
	boolean valid;

	island[RimboRow][RimboColumn].setText("");

	valid=false;
	if(direction.compareTo("haut")==0)
	    {
		if(this.RimboRow>0)
		    {
			valid=true;
			this.RimboRow-=1;
			System.out.println("Vers le nord");
		    }
	    }
	else if (direction.compareTo("gauche")==0)
	    {
		if(this.RimboColumn>0)
		    {
			valid=true;
			this.RimboColumn-=1;
			System.out.println("Vers l'ouest");
		    }
	    }
	else if (direction.compareTo("bas")==0)
	    {
		if(this.RimboRow<(this.island.length-1))
		    {
			valid=true;
			this.RimboRow+=1;
			System.out.println("Vers le sud");
		    }
	    }
	else
	    {
		if(this.RimboColumn<(this.island[0].length-1))
		    {
			valid=true;
			this.RimboColumn+=1;
			System.out.println("Vers l'est");
		    }
	    }

	island[RimboRow][RimboColumn].setText("R");

	if(valid)
	    {
		island[RimboRow][RimboColumn].explore();
	    }
	else
	    {
		System.out.println("Je suis au bord de l'océan");
	    }
	
	return true;
	
    }

}