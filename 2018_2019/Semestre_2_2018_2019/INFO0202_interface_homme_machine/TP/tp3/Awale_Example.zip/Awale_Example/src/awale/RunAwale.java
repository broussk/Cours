package awale;

class RunAwale
{
    public static void main(String args[])
    {
	AwaleConfiguration jeu=new AwaleConfiguration();
	if(jeu==null)
	    {
		System.out.println("Erreur lors de l'instanciation du jeu");
	    }
    }
}