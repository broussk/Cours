package awale;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.BoxLayout;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Graphics;

class AwaleWindows extends JFrame
{
    public static final long serialVersionUID=1000;

    public static final int HEIGHT=300;
    public static final int WIDTH=600;
    

    protected JMenuItem jmi_NouvellePartie=new JMenuItem("Nouvelle partie");
    protected JMenuItem jmi_Quitter=new JMenuItem("Quitter");
    protected JMenu jm_Fichier=new JMenu("Fichier");
    protected JMenuBar jmb_AwaleWindowsBar=new JMenuBar();
    protected JPanel jp_mainPanel=new JPanel();
    protected JPanel jp_Player1=new JPanel();
    protected JPanel jp_Player2=new JPanel();
    protected JLabel JL_joueur1=new JLabel();
    protected JLabel JL_joueur2=new JLabel();
    protected JLabel[] jl_scores=new JLabel[2];
    protected JPanel JP_playing_zone=new JPanel();
    protected AwaleWindows.GamerZone gamerZone1=new GamerZone();
    protected GamerZone gamerZone2=new GamerZone();
    protected BoxLayout boxLayout;
    protected GridLayout gridLayout=new GridLayout(1,6);

    protected Toolkit toolkit;
    protected Dimension screenSize;

    private AwaleConfiguration awaleConfiguration;
    private Awale controler;
    private int[] seeds=new int[2*6];
    private JLabel[] seedZones=new JLabel[12];
    AwaleWindows(AwaleConfiguration awaleConfiguration)
    {
	setTitle("Awale game");

	jmi_NouvellePartie.addActionListener(new ActionListener() 
	    {
		public void actionPerformed(ActionEvent ev)
		{
		    setVisible(false);
		    AwaleWindows.this.awaleConfiguration.reactivate();
		}
	    });

	jm_Fichier.add(jmi_NouvellePartie);
	jm_Fichier.add(jmi_Quitter);
	jmi_Quitter.addActionListener(new ExitAction());
	jmb_AwaleWindowsBar.add(jm_Fichier);
	setJMenuBar(jmb_AwaleWindowsBar);

	jp_Player1.setPreferredSize(new Dimension(WIDTH,HEIGHT/8));
	jp_Player2.setPreferredSize(new Dimension(WIDTH,HEIGHT/8));

	jl_scores[0]=new JLabel("0");
	jl_scores[1]=new JLabel("0");

	jp_Player1.add(JL_joueur1);
	jp_Player1.add(jl_scores[0]);

	jp_Player2.add(JL_joueur2);
	jp_Player2.add(jl_scores[1]);


	boxLayout=new BoxLayout(JP_playing_zone,BoxLayout.Y_AXIS);
	JP_playing_zone.setLayout(boxLayout);
	gamerZone1.setLayout(gridLayout);
	gamerZone2.setLayout(gridLayout);
	for(int i=0;i<6;i++)
	    {
		seedZones[i]=new SeedZone(i);
		gamerZone1.add(seedZones[i]);
		seedZones[6+i]=new SeedZone(6+i);
		gamerZone2.add(seedZones[6+i]);
	    }
	JP_playing_zone.add(gamerZone1);
	JP_playing_zone.add(gamerZone2);
	
	jp_mainPanel.setLayout(new BorderLayout());
	jp_mainPanel.add(jp_Player1,BorderLayout.NORTH);
	
	jp_mainPanel.add(JP_playing_zone,BorderLayout.CENTER);
	jp_mainPanel.add(jp_Player2,BorderLayout.SOUTH);
	add(jp_mainPanel);

	setDefaultCloseOperation(EXIT_ON_CLOSE);

	setSize(WIDTH,HEIGHT);
	setResizable(false);
	toolkit=Toolkit.getDefaultToolkit();
	screenSize=toolkit.getScreenSize();
	setLocation((int)((screenSize.getWidth()/2)-getWidth()/2),(int)((screenSize.getHeight()/2)-getHeight()/2));

	
	this.awaleConfiguration=awaleConfiguration;
    }

    void init(String nomJoueur1, String nomJoueur2)
    {
	JL_joueur1.setText(nomJoueur1);
	JL_joueur2.setText(nomJoueur2);
	
	for(int i=0;i<seeds.length;i++)
	    {
		seeds[i]=4;
		seedZones[i].setText("4");
		
	    }

	for(int i=0;i<jl_scores.length;i++)
	    {
		jl_scores[i].setText("0");
	    }
	
	controler=new Awale(seeds);
	setVisible(true);
    }

    class GamerZone extends JPanel
    {
	public static final long serialVersionUID=1212;

	public void paintComponent(Graphics g)
	{
	    super.paintComponent(g);
	    g.drawRoundRect(5,0,580,85,10,10);
	}
    }

    class SeedZone extends JLabel
    {
	public static final long serialVersionUID=1313;

	private int location;
	SeedZone(int location)
	{
	    super("4");
	    setHorizontalAlignment(SwingConstants.CENTER);

	    this.location=location;

	    addMouseListener(new MouseListener() 
		{
		    public void mouseClicked(MouseEvent e)
		    {
			if(e.getButton()==MouseEvent.BUTTON1)
			    {
				System.out.println(SeedZone.this.location/6+" "+SeedZone.this.location%6);
				if(AwaleWindows.this.controler.canBePlayed(SeedZone.this.location))
				    {
					try
					    {
						int i=SeedZone.this.location;
						int nbSeeds=Integer.parseInt(seedZones[i].getText());
						seedZones[i].setText("0");
						seedZones[i].paintImmediately(0,0,seedZones[i].getWidth(),seedZones[i].getHeight());
						Thread.sleep(500);
						i=nextSeedCase(i);
						while(nbSeeds>0)
						    {
							seedZones[i].setText(""+(1+Integer.parseInt(seedZones[i].getText())));
							seedZones[i].paintImmediately(0,0,seedZones[i].getWidth(),seedZones[i].getHeight());
							nbSeeds--;
							if(nbSeeds > 0)
							    {
								i=nextSeedCase(i);
							    }
							Thread.sleep(500);
						    }
						updateSeeds();
						int currentPlayer=AwaleWindows.this.controler.getCurrentPlayer();
						while(AwaleWindows.this.controler.canBeCaptured(i))
						    {
							int nouveau_score=Integer.parseInt(jl_scores[currentPlayer].getText())+Integer.parseInt(seedZones[i].getText());
							jl_scores[currentPlayer].setText(""+nouveau_score);
							jl_scores[currentPlayer].paintImmediately(0,0,jl_scores[currentPlayer].getWidth(),jl_scores[currentPlayer].getHeight());
							seedZones[i].setText("0");
							
							seedZones[i].paintImmediately(0,0,seedZones[i].getWidth(),seedZones[i].getHeight());
							i=previousSeedCase(i);
						    }
						AwaleWindows.this.controler.finishTurn();
					    }
					catch(java.lang.InterruptedException ie)
					    {
						System.exit(0);
					    }
				    }
			    }
		    }

		    public void mouseExited(MouseEvent e){}
		    public void mouseEntered(MouseEvent e){}
		    public void mouseReleased(MouseEvent e){}
		    public void mousePressed(MouseEvent e){}
		});
	}

	public String toString()
	{
	    return location/6+" "+location%6+" "+getText();
	}

	public void paintComponent(Graphics g)
	{
	    super.paintComponent(g);
	    g.drawOval(10,5,75,75);
	}

	private void updateSeeds()
	{
	    for(int i=0;i<seeds.length;i++)
		{
		    seeds[i]=Integer.parseInt(seedZones[i].getText());
		}
	}

	private int nextSeedCase(int i)
	{
	    if(i>=seedZones.length/2)
		{
		    i++;
		    if(i==seedZones.length)
			{
			    i=(seedZones.length/2)-1;
			}
		}
	    else
		{
		    i--;
		    if(i<0)
			{
			    i=seedZones.length/2;
			}
		}

	    return i;
	}
	
	private int previousSeedCase(int i)
	{
	    if(i<seedZones.length/2)
		{
		    i++;
		    if(i==seedZones.length/2)
			{
			    i=seedZones.length-1;
			}
		}
	    else
		{
		    i--;
		    if(i==(seedZones.length/2)-1)
			{
			    i=0;
			}
		}

	    return i;
	}
    }

}
