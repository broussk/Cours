package awale;

class Awale
{
    private int[] seeds=null;
    private int currentPlayer;

    Awale(int[] seeds)
    {
	this.seeds=seeds;
	currentPlayer=0;
    }

    public boolean isFinished()
    {
	int player1Seeds, player2Seeds;
	
	player1Seeds=player2Seeds=0;
	
	for(int i=0;i<6;i++)
	    {
		player1Seeds+=seeds[i];
		player2Seeds+=seeds[6+i];
	    }

	return ( (player1Seeds==0) || (player2Seeds==0) );
    }

    private boolean isValid(int location)
    {
	if(seeds==null)
	    {
		return false;
	    }

	if(seeds[location]==0)
	    {
		return false;
	    }

	return true;
    }

    public boolean canBePlayed(int location)
    {
	System.out.println("Location "+location+" Play ? "+location/6+" "+location%6);
	return isValid(location) && currentPlayer == (location/6) && seeds[location]!=0;
    }

    public boolean canBeCaptured(int location)
    {
	System.out.println("Location "+location+" Capture ? "+location/6+" "+location%6);
	return isValid(location) && currentPlayer != (location/6) && ( seeds[location]==2 || seeds[location]==3 );
    }

    public String toString()
    {
	String msg="";
	if(seeds!=null)
	    {
		for(int i=0;i<seeds.length;i++)
		    {
			msg+=seeds[i];
			if(i%6==0)
			    {
				msg+="\n";
			    }
		    }
	    }
	return msg;
    }

    public int getCurrentPlayer()
    {
	return currentPlayer;
    }

    public void finishTurn()
    {
	currentPlayer++;
	currentPlayer%=2;
    }
}