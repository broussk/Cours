package awale;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.Toolkit;
import java.awt.Dimension;

import java.util.Vector;

class AwaleConfiguration extends JFrame
{
    public static final long serialVersionUID=1111;

    public static enum Niveau{FACILE, MOYEN, DIFFICILE};
    protected JComboBox<String> typeJoueur1, typeJoueur2;
    protected Vector<String> type=new Vector<String>();
    protected JLabel jLabelJoueur1=new JLabel("Joueur 1");
    protected JTextField jTextFieldJoueur1=new JTextField("Nom Joueur 1");
    protected JLabel jLabelJoueur2=new JLabel("Joueur 2");
    protected JTextField jTextFieldJoueur2=new JTextField("Nom Joueur 2");
    protected BoxLayout layout;
    protected JPanel mainPanel=new JPanel();
    protected JPanel panelJoueur1=new JPanel();
    protected JPanel panelJoueur2=new JPanel();
    protected JPanel panelBoutons=new JPanel();
    protected JButton boutonValider=new JButton("Valider");
    protected JButton boutonQuitter=new JButton("Quitter");
    protected Toolkit toolkit;
    protected Dimension screenSize;

    private AwaleWindows awaleWindows;
    public static final int WIDTH=400;
    public static final int HEIGHT=150;
 
    AwaleConfiguration()
    {
	setTitle("Awale Configuration");

	addActions();
	
	layout=new BoxLayout(mainPanel,BoxLayout.Y_AXIS);
	mainPanel.setLayout(layout);

	type.add("Humain");
	type.add("Ordinateur");

	panelJoueur1.add(jLabelJoueur1);
	panelJoueur1.add(jTextFieldJoueur1);
	typeJoueur1=new JComboBox<String>(type);
	panelJoueur1.add(typeJoueur1);

	mainPanel.add(panelJoueur1);

	panelJoueur2.add(jLabelJoueur2);
	panelJoueur2.add(jTextFieldJoueur2);
	typeJoueur2=new JComboBox<String>(type);
	panelJoueur2.add(typeJoueur2);
	
 
	mainPanel.add(panelJoueur2);

	panelBoutons.add(boutonValider);
	panelBoutons.add(boutonQuitter);

	mainPanel.add(panelBoutons);

	getContentPane().add(mainPanel);
	
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	toolkit=Toolkit.getDefaultToolkit();
	screenSize=toolkit.getScreenSize();
	
	setSize(WIDTH,HEIGHT);
	setLocation((int)((screenSize.getWidth()/2)-getWidth()/2),(int)((screenSize.getHeight()/2)-getHeight()/2));
	setResizable(false);
	setVisible(true);

	awaleWindows=new AwaleWindows(this);
    }

    void reactivate()
    {
	setVisible(true);
    }

    private void addActions()
    {
	boutonQuitter.addActionListener(new ExitAction());
	boutonValider.addActionListener(new ActionListener() 
	    {
		public void actionPerformed(ActionEvent ev)
		{
		    System.out.println("Joueur 1 = "+jTextFieldJoueur1.getText()+", type = "+typeJoueur1.getSelectedObjects()[0]);
		    System.out.println("Joueur 2 = "+jTextFieldJoueur2.getText()+", type = "+typeJoueur2.getSelectedObjects()[0]);
		    setVisible(false);
		    awaleWindows.init(jTextFieldJoueur1.getText(),jTextFieldJoueur2.getText());

		}
	    });
    }
}
