#include "fonctions.h"
#include <stdlib.h>
#include <stdio.h>
//Fonction Exercice 2




//Fonctions Exercice 1
int carre(int x){
  return x*x;
}

int verifier(int ch){
  if(ch>=45)
    return (100);
  else
    return (10*10);
}

void display(){
  printf("Non c'est le C++!");
  // main();
}
