#include <stdlib.h>
#include <stdio.h>
#include "fonctions.h"

int main(){
  //CODE 5
  // int a,b,c;
  // c=0;
  // b=0;
  // if(a>b)
  //   c = 0;
  // else
  //   b = 0;
  // return 0;

  //CODE 4
  // int i=45,c;
  // c = multiplier(i*1000);
  // printf("\n%d",c);

  //CODE 3
  // int i=45,c;
  // c = verifier(i);
  // printf("\n%d",c);

  //CODE 2
  // printf("\nLe programme principal survit !!");
  // main();

  //CODE 1
  // printf("\nLe C est le meilleur des langages ?");
  // display();
}
