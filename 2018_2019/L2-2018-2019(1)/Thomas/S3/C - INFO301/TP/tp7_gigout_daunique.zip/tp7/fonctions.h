void display();
int verifier(int ch);
int carre(int x);
