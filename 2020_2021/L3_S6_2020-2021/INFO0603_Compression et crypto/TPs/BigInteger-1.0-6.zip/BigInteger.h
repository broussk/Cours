/// @file	BigInteger.cpp
/// @author Pascal Mignot
/// @date 26/03/2017
/// @version 1.0.4

#ifndef _BIGINTEGER_H
#define _BIGINTEGER_H
//#pragma once
#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <cstring>
#include "BigType.h"

class BigSignedInteger;

/// @brief class to store large integers and manage arithmetic operations between them
/// @details the underlying type is a std::vector of digit_t (=uint32_t).
class BigInteger {
private:
	digit_t _ShiftLeft(const BigInteger &b, size_t shift);
	digit_t _ShiftRight(const BigInteger &b, size_t shift);
protected:
	std::vector<digit_t>   digits;	///< underlying storage type (vector of digits).
	uint32_t *data() const;		  // return a pointer to the underlying digits array.
public:
	uint32_t& operator[](size_t i);			  // access element of digits array (non-const).
	const uint32_t& operator[](size_t i) const;  // access element of digits array (const).

	/// @name Constructors / Destructor
	//@{
	BigInteger();						// default constructor (= empty vector of digit).
	BigInteger(digitsize_t ndigits);	// constructor by number of digits (= 32 bits block).
	BigInteger(bitsize_t nbits);		// constructor by number of bits
	BigInteger(digit_t  digit);			// constructor with a short (=one digit)
	BigInteger(const BigInteger &d);    // copy constructor.
	BigInteger(BigInteger &&d);			// move constructor.
	~BigInteger() {};					// destructor.
	//@}

	/// @name Setters
	//@{
	digit_t SetZero();	          // set all digits to zero.
	void SetEqual(const BigInteger &obj); // set equal to a BigInteger.
	void SetDigit(digit_t value);         // all digits to 0 except the first one to value, size unchanged.
	size_t SetShort(digit_t value);          // first digit set to value, size set to 1.
	BigInteger& operator=(const BigInteger &obj); // assignation per copy .
	uint32_t zero(size_t iMin = 0);			  // set to zero.
	void SetMax(size_t iMin = 0);		  // set to maximum value.
	void swap(BigInteger &u);             // swap with another BigInteger.
	//@}

	/// @name Size query and adjusters
	//@{
	digitsize_t Sizeof() const;		 // number of significant digits in the BigInteger storage.
	size_t AdjustSize();		 // adjust the storage size of the BigInteger.
	bitsize_t BitLength() const; // highest significant bit in the BigInteger.
	bytesize_t ByteLength() const;	 // highest significant byte in the BigInteger.
	size_t size() const;	     // underlying storage size of the BigInteger.
	void resize(size_t sz) const;  // resize the underlying storage size to sz digits.
	void resize(bitsize_t sz);	 // resize the underlying storage size to sz bits.
	//@}

	/// @name Converters
	//@{
	size_t ConvFromOctets(const std::vector<uint8_t> &octets); // convert array of bytes to a BigInteger
	size_t ConvToOctets(std::vector<uint8_t> &octets) const;   // convert a BigInteger to an array of bytes
	size_t ConvFromDecimal(const std::string &decimal);        // convert a string representing a decimal to a BigInteger
	size_t ConvToDecimal(std::string &decimal) const;          // convert a BigInteger to a string representing the corresponding decimal.
	size_t ConvFromHex(const std::string &hexa);               // convert a string representing an hexadecimal to a BigInteger
	size_t ConvToHex(std::string &hexa) const;                 // convert a BigInteger to a string representing the corresponding hexadecimal.
	//@}

	/// @name Arithmetics between a BigInteger and a short integers
	//@{
	uint32_t ShortAdd(const BigInteger &u, const digit_t &v);			// add a digit integer to a BigInteger
	uint32_t ShortSub(const BigInteger &u, const digit_t &v);	// subtract a digit integer from a BigInteger
	uint32_t ShortMult(const BigInteger &u, const digit_t &v);	// multiply a digit integer to a BigInteger
	digit_t ShortDiv(const BigInteger &u, digit_t d);   // divide a BigInteger by a digit integer, return the remainder
	digit_t ShortMod(digit_t m); // return the remainder of the division the current BigInteger by a digit integer
	//@}

	/// @name Arithmetics between two BigInteger
	//@{
	uint32_t Multiply(const BigInteger &u, const BigInteger &v); // multiply two BigInteger.
	uint32_t Add(const BigInteger &u, const BigInteger &v); // add two BigInteger.
	uint32_t Subtract(const BigInteger &u, const BigInteger &v); // subtract two BigInteger.
	uint32_t Divide(BigInteger &r, const BigInteger &u, const BigInteger &v); // divide two BigInteger, also return the remainder
	uint32_t Modulo(const BigInteger &u, const BigInteger &v); // remainder of the divide two BigInteger.
	uint32_t Modulo(const BigSignedInteger &u, const BigInteger &v);
	//@}

	/// @name Viewers
	//@{
	void viewHex(const char *title = nullptr, bool eol = true, std::ostream &stream = std::cout) const; // view the BigInteger as an hexadecimal
	void viewDec(const char *title = nullptr, bool eol = true, bool sep = true, std::ostream &stream = std::cout) const; // view the BigInteger as a decimal
	friend std::ostream & operator<<(std::ostream &stream, const BigInteger &d); // overloading for BigInteger as decimal.
	//@}

	/// @name Bit-wise operations
	//@{
	uint32_t SetBit(size_t n, int value); // Set bit n of a (0..nbits-1) with value 1 or 0.
	uint32_t GetBit(size_t ibit) const; // Returns value 1 or 0 of bit n of a (0..nbits-1).
	void XorBits(const BigInteger &b, const BigInteger &c);	// Computes bitwise operation a = b XOR c.
	void OrBits(const BigInteger &b, const BigInteger &c);	// Computes bitwise operation a = b OR c.
	void AndBits(const BigInteger &b, const BigInteger &c);	// Computes bitwise operation a = b AND c.
	void NotBits(const BigInteger &b);	// Computes bitwise a = NOT b (flip up to the MSB).
	digit_t ShiftLeft(size_t shift);    // In-place shift to left.
	digit_t ShiftRight(size_t shift);   // In-place shift to right.
	void ShiftLeft(const BigInteger &b, size_t n);  // shift a BigInteger n bits to left.
	void ShiftRight(const BigInteger &b, size_t n); // shift a BigInteger n bits to right.
	//@}

	/// @name Tests
	//@{
	//  return true iff the two BigInteger represent the same number.
	friend bool operator==(const BigInteger &a, const BigInteger &b);
	// return true iff the BigInteger is a representation of zero.
	bool isZero() const;
	// return true iff the BigInteger store a value no larger than a digit.
	bool isShort(digit_t val) const;
	//@}

	friend int Compare(const BigInteger &a, const BigInteger &b);
};

/*=================================================================================================*/
/// @brief compare two BigIntegers and return the sign of the difference.
/// @param	a	First BigInteger to be compared.
/// @param	b	Second BigInteger to be compared.
/// @return	Negative if 'a' is less than 'b', 0 if they are equal, or positive if it is greater.
int Compare(const BigInteger &a, const BigInteger &b);

/***************************************************************************************
Inline implementation
****************************************************************************************/

/*=================================================================================================*/
/// @brief Default constructor.
/// @details Constructs a BigInteger representing zero. The underlying storage is
/// a vector of size zero.
inline BigInteger::BigInteger() : digits() {}

/*=================================================================================================*/
/// @brief Constructor a BigInteger using ndigits digit_t,
/// @details meaning the total storage size allocated is 32*ndigits.
/// @param	ndigits	the number of 32 digits in the underlying storage.
///
inline BigInteger::BigInteger(digitsize_t ndigits)
	: digits(ndigits.value < 1 ? 1 : ndigits.value, 0) {}

/*=================================================================================================*/
/// @brief Constructor a BigInteger using nbits bits,
/// @details meaning the total storage size allocated is ceil(nbits/32) digits.
/// @param	nbits	minimum number of bits storable in the underlying digits vector.
inline BigInteger::BigInteger(bitsize_t nbits)
	: digits(nbits.value / digit_t::BitSize
		+ (nbits.value % digit_t::BitSize ? 1 : 0)) {}

/*=================================================================================================*/
/// @brief Constructor a BigInteger using a Short,
/// @details meaning the total storage size allocated is one ndigit.
/// @param	digit the value to use to initialize the BigInteger.

inline BigInteger::BigInteger(digit_t digit): digits() {
	if (digit.value != 0) {
		resize(1);
		digits[0] = digit.value;
	}
}

/*=================================================================================================*/
/// @brief Copy constructor. Build a BigInteger from another one.
/// @param	d	The BigInteger to copy.
inline BigInteger::BigInteger(const BigInteger &d) : digits(d.digits) {};

/*=================================================================================================*/
/// @brief Move constructor. Build a BigInteger by moving another one.
/// @param	d	The temporary BigInteger to move.
inline BigInteger::BigInteger(BigInteger &&d) : digits(std::move(d.digits)) {};

/*=================================================================================================*/
/// @brief Copy assignation. Assign a BigInteger from another one.
/// @details Afterward, both objects have the same size and all of theirs digits are also
/// 		the same.
/// @param	obj	The BigInteger to assign from.
inline BigInteger& BigInteger::operator=(const BigInteger &obj) {
	SetEqual(obj); return *this;
}

/*=================================================================================================*/
/// @brief This method sets all this digits to 0 without resizing it.
/// @param	iMin	index of the first digit to be set to zero.
inline uint32_t BigInteger::zero(size_t iMin) {
	if (size() && (iMin <= digits.size())) {
		for(size_t i=iMin; i<digits.size(); ++i) digits.data()[i] = 0;
        // std::memset(digits.data() + iMin, 0x00, (digits.size() - iMin)*sizeof(digit_t));
	}
	return 0;
}

/*=================================================================================================*/
/// @brief This method sets all this digits to the maximum value possible with this number of digits
/// @details (should be 2 ^ (32.n) - 1 on a n digits number.MSB is lost.
/// @param	iMin	index of the first digit to be set to the maximum.
inline void BigInteger::SetMax(size_t iMin) {
	if (size() && (iMin <= digits.size())) {
		for(size_t i=iMin; i<digits.size(); ++i) digits.data()[i] = 0xffffffff;
        // std::memset(digits.data() + iMin, 0xff, (digits.size() - iMin)*sizeof(digit_t));
	}

}

/*=================================================================================================*/
/// @brief Return a digit_t pointer to the underlying storage of the BigInteger.
///	@details The indice of the LSB is 0. The indice of the MSB is size() - 1.
///	@warning may be null is size = 0.
/// @return	a digit_t* pointer to the underlying storage.

inline uint32_t *BigInteger::data() const { return const_cast<uint32_t*>(&(digits.data()->value)); }

/*=================================================================================================*/
/// @brief Direct access to individual digit of the underlying digit array (non const object).
/// @details 0 is the index of the least significant digit, the following digits being ordered by
/// 		order of increasing importance. The maximum index is size() - 1.
/// @param	i	Zero-based index of the digit of a BigInteger.
/// @return	The ith digit of the BigInteger.
inline uint32_t& BigInteger::operator[](size_t i) { return digits[i].value; }

/*=================================================================================================*/
/// @brief Direct access to individual digit of the underlying digit array (const object).
/// @details 0 is the index of the least significant digit, the following digits being ordered by order
/// 		of increasing importance. The maximum index is size() - 1.
/// @param	i	Zero-based index of the digit of a BigInteger.
/// @return	The ith digit of the BigInteger.
inline const uint32_t& BigInteger::operator[](size_t i) const { return digits[i].value; }

/*=================================================================================================*/
/// @brief  Swaps two BigIntegers.
/// @param u	The BigInteger that will be swapped with the current BigInteger.

inline void BigInteger::swap(BigInteger &u) { digits.swap(u.digits); }

/*=================================================================================================*/
/// @brief Return the number of digits used by the underlying storage of a BigInteger.
/// @details Can be more than the minimal number of digits needed to store the number (see Sizeof).
/// @return	the storage size.

inline size_t BigInteger::size() const { return digits.size(); }

/*=================================================================================================*/
/// @brief Resizes a BigInteger too the specified number of digits.
/// @details If sz is smaller than the current size,
/// the exceeding bits are truncated or zeroed on the last significant digit.
/// If sz is bigger, the new digits are all set to zero.
/// @param	sz	The new underlying number of digits to represent the BigInteger.

inline void BigInteger::resize(bitsize_t sz) {
	size_t  nBits = sz % digit_t::BitSize;
	size_t  nDigits = sz / digit_t::BitSize + (nBits ? 1 : 0);
	// trimming the exceeding bits
	if ((nBits != 0) && (nDigits < digits.size()))
		digits[nDigits - 1] = digits[nDigits - 1] & (digit_t::MaxValue >> (digit_t::BitSize - nBits));
	// resizing
	digits.resize(nDigits);
}

/*=================================================================================================*/
/// @brief Resizes a BigInteger too the specified number of bits.
/// @details If it's smaller than the current size,
/// the exceeding digits are truncated. If it's bigger, the new digits are all set to zero.
/// @param	sz	The new underlying number of digits to represent the BigInteger.

inline void BigInteger::resize(size_t sz) const {
	std::vector<digit_t> &mutable_digits = const_cast<std::vector<digit_t>&>(digits);
	mutable_digits.resize(sz);
}


/*=================================================================================================*/
/// @brief Stream output overloading.
/// @details The BigInteger is displayed as a big decimal.
/// @param stream	The output stream.
/// @param d	  	The BigInteger to display.
/// @return	the output stream to chain.

inline std::ostream & operator<<(std::ostream &stream, const BigInteger &d) {
	d.viewDec(nullptr, false, true, stream);
	return stream;
}

/*=================================================================================================*/
/// @brief Inplace shift to the left.
/// @details The result is placed in the current BigInteger, which is resized if needed.
/// @param	shift	The number of bits to shift.
/// @return	the carry of the shift had forced a resizing (can be ignored)

inline digit_t BigInteger::ShiftLeft(size_t shift) { return this->_ShiftLeft(*this, shift); };

/*=================================================================================================*/
/// @brief Inplace shift to the right.
/// @details The result is placed in the current BigInteger, which is resized if needed.
/// @param	shift	The number of bits to shift.
/// @return	A digit_t.
inline digit_t BigInteger::ShiftRight(size_t shift) { return this->_ShiftRight(*this, shift); };

#endif
