/// @file	BigInteger.cpp
/// @author Pascal Mignot
/**
@mainpage Documentation BigInteger
@author Pascal Mignot

@version 1.0.0 (2016, march)
- Initial release.
- Implements the big integer class.
@version 1.0.1 (2016, march)
- conversion bugs (decimal) fixed.
- Optimization of conversion functions.
- Implementation of re-entering parameters for short and big Integer arithmetics.
- bitsize_t and bytesize_t type additions with user-defined conversion and user defined
literal (_bits and _bytes).
@version 1.0.2 (2016, march)
- Divide bug fixed.
- BigType and BigRandomInteger unit added.
- digitsize_t now a plain type with integrated constants.
- new BigInteger constructors: BigInteger(digit_t) now construct a short (warning: change),
and BigInteger(digitsize_t) construct a big integer with specified number of digits.
- accesses to internal digits of a big integer are now protected.
- all re-entering arithmetic functions are now optimized (using temporary reference).
- several new methods added (using bitsize_t).
@version 1.0.3 (2016, april)
- const coherence fixed (BigInteger parameter which should be constant were internally
modified in order to provide identical digits accesses, besides without modifying
the stored value).
- as a consequence, all methods and parameters that should be constant are now constants.
- using const object have no effect on object capabilities.
@version 1.0.4 (2017, march)
- full compliance to -Wconversion fixed.
@version 1.0.5 (2018, march)
- full compliance to -Wextra -Wsign-conversion fixed.
- hack for reference to real/temporary object removed.
*/

#include <cassert>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cassert>
#include <chrono>
#include "BigType.h"
#include "BigInteger.h"

//#define TRACE(x) x
//#define LOG(x,...) printf(x,__VA_ARGS__)
// #define LOG(x,...) printf("[" __FUNCTION__ "] " x "\n",__VA_ARGS__)
#define TRACE(x)
#define LOG(x,...)

std::mt19937 RandomlySeededMersenneTwister() {
	std::chrono::system_clock::time_point now = std::chrono::system_clock::now();
	std::mt19937 rng( (std::uint_fast32_t)now.time_since_epoch().count() );
	rng.discard(700000);
	return rng;
}
namespace Byte {
	std::mt19937	&&gen = RandomlySeededMersenneTwister();
	std::uniform_int_distribution<short>	rnd(0, 255);
	std::uniform_int_distribution<short>	rnd_nz(1, 255);
}

// class constants
const size_t digit_t::ByteSize = sizeof(uint32_t);
const size_t digit_t::OctalSize = 2 * sizeof(uint32_t);
const size_t digit_t::BitSize = 8 * sizeof(uint32_t);
const uint32_t digit_t::MaxValue = 0xFFFFFFFFUL;
const uint32_t digit_t::HiBitMask = 0x80000000UL;

/// internal class for conditional reference 
/// this represented binary should always be constant (even if it internally changes)
/*
class BigIntegerAuto {
protected:
	BigInteger	*tmp;
	BigInteger  &ref;
public:
	BigIntegerAuto(bool isSame, const BigInteger &b)
		: tmp(isSame ? new BigInteger(b) : nullptr),
		  ref(isSame ? *tmp : const_cast<BigInteger&>(b)) {}
	~BigIntegerAuto() {
		delete tmp; // no effect if tmp already null
	}
	// forwarding all main method	
	inline size_t size() const { return ref.size(); }
	inline void resize(size_t sz) { return ref.resize(sz); };
	inline digitsize_t Sizeof() const { return ref.Sizeof(); };
	inline uint32_t& operator[](size_t i) { return ref[i]; }
	inline const uint32_t& operator[](size_t i) const { return ref[i]; };
	// other cases: self
	inline BigInteger& self() { return ref;  }
};
*/

/*****************************************/
/* uint32_t  Multiply/Divide             */
/*****************************************/

/*=================================================================================================*/
/// @brief Hardware multiply of two unsigned 32bit integer (x * y)
/// using 64bit multiplication.
///
/// @param	x	first unsigned 32bit integer to multiply.
/// @param	y	second unsigned 32bit integer to multiply.
/// @param	p	the 64bit result as an array of two 32 bits integer.
///
/// @return	0 (to be able to call and return).

inline int hwMultiply(uint32_t p[2], uint32_t x, uint32_t y) {
	/* Use a 64-bit temp for product */
	uint64_t t = (uint64_t)x * (uint64_t)y;
	/* then split into two parts */
	p[1] = (uint32_t)(t >> 32);
	p[0] = (uint32_t)(t & 0xFFFFFFFF);
	return 0;
}

/*=================================================================================================*/
/// @brief Hardware divide a 64bit by a 32bit integer
/// @param pq	The LSB of the quotient of the division (32 first bits).
/// @param pr	The reminder of the division (32bit).
/// @param u  	The 64bit integer to divide for, passed as an array of two 32bit integers.
/// @param v  	The 32bit integer to divide by.
///
/// @return The MSB of the quotient of the division (32bit overflow).

inline uint32_t hwDivide(uint32_t &pq, uint32_t &pr, const uint32_t u[2], uint32_t v) {
	uint64_t uu, q;
	uu = (uint64_t)u[1] << 32 | (uint64_t)u[0];
	q = uu / (uint64_t)v;
	//r = uu % (uint64_t)v;
	pr = (uint32_t)(uu - q * v);
	pq = (uint32_t)(q & 0xFFFFFFFF);
	return (uint32_t)(q >> 32);
}

/*****************************************/
/* COMPARISON                            */
/*****************************************/

/*=================================================================================================*/
/// @brief Compare two BigIntegers. 
/// @details The two BigIntegers are considered as equal if all theirs digits
/// equal, except theirs sizes are different, any additional digits must be null.
/// Also works if any of the BigIntegers have a null size.
/// 
/// Algorithm: a==b iff a[i]==b[i] for all i <min(size(a),size(b))
///            a[i]==0 for all i>=size(a)>size(b) (same with b if size(a)<size(b)).
///
/// @param	a	The first BigInteger instance to compare.
/// @param	b	The second BigInteger instance to compare.
///
/// @return	true if the parameters are considered equivalent.

bool operator==(const BigInteger &a, const BigInteger &b) {
	const std::pair<BigInteger, BigInteger> v = std::minmax(a, b,
		[](const BigInteger &a, const BigInteger &b) { return a.size() < b.size(); });
	size_t i = 0;
	for (; i < v.first.size(); ++i)
		if (v.first[i] != v.second[i]) return false;
	for (; i < v.second.size(); ++i)
		if (v.second[i] != 0) return false;
	return true;
}

/*=================================================================================================*/
/// @brief Query if this object is equivalent to zero. 
/// @details The object is considered as equivalent to zero,
/// if it has no digit (size()==0) or if all of its digits are zero.
///
/// @return	true if zero, false if not.

bool BigInteger::isZero() const {
	if (size() == 0) return true;
	for (size_t i = 0; i < size(); i++)
		if (digits[i] != 0) return false;
	return true;
}

/*=================================================================================================*/
/// @brief Compares two const BigInteger objects to determine their relative ordering,
/// @details meaning returns sign of (a - b) as 0, +1 or -1. Not constant-time.
///
/// @param	a	First BigInteger to be compared.
/// @param	b	First BigInteger to be compared.
///
/// @return	Negative if 'a' is less than 'b', 0 if they are equal, or positive if it is greater.
int Compare(const BigInteger &a, const BigInteger &b) {
	size_t  ndigits;
	if (a.size() != b.size()) {
		size_t na = a.Sizeof(), nb = b.Sizeof();
		if (na > nb) return 1;
		else if (na < nb) return -1;
		ndigits = na;
	}
	else ndigits = a.size();
	/*  Use constant-time fn if equal length */
	/** Returns sign of (a - b) as 0, +1 or -1 (constant-time) */
	/* All these vars are either 0 or 1 */
	unsigned int gt = 0;
	unsigned int lt = 0;
	unsigned int mask = 1;	/* Set to zero once first inequality found */
	while (ndigits--) {
		gt |= (a[ndigits] > b[ndigits]) & mask;
		lt |= (a[ndigits] < b[ndigits]) & mask;
		unsigned int c = (gt | lt);
		mask &= (c - 1);	/* Unchanged if c==0 or mask==0, else mask=0 */
	}
	return (int)gt - (int)lt;	/* EQ=0 GT=+1 LT=-1 */
}

/*=================================================================================================*/
/// @brief Query if the BigInteger is equivalent to a short BigInteger (=one digit), 
/// @details meaning that its first digit is equal to val, and all other digits (if exists) 
/// 		are zeros. If val=0, also return true if the BigInteger has a zero size.
///
/// @param	val	The value to compare the short BigInteger.
///
/// @return	true if this is a short BigInteger with value val, false if not.

bool BigInteger::isShort(digit_t val) const {
	if (size() == 0) return (val == 0 ? true : false);
	if (digits[0] != val.value) return false;
	for (size_t i = 1; i < size(); i++)
		if (digits[i] != 0) return false;
	return true;
}

/*****************************************/
/* SETTERS                               */
/*****************************************/

/*=================================================================================================*/
/// @brief Set a BigInteger to zero by giving him a zero size.
/// @return	0 (to be able to call and return).
digit_t BigInteger::SetZero() {
	resize(0);
	return 0;
}

/*=================================================================================================*/
/// @brief Set a BigInteger as a single digit value. 
/// @details If the BigInteger have more than one digit,
/// all the subsequent digits are set to 0. If the BigInteger have no digit, it is resized
/// to zero.
/// @param	value	the value the digit must be set to.
void BigInteger::SetDigit(digit_t value) {
	BigInteger  &a = *this;
	size_t  ndigits = size();
	if (ndigits == 0) resize(1);
	a[0] = value;
	for (size_t i = 1; i < ndigits; i++) a[i] = 0;
}

/*=================================================================================================*/
/// @brief Set a BigInteger as a short BigInteger
/// @details meaning that the BigInteger is resized to 1, and its digit is set to the value. 
/// @details Exception: if the value is zero, the BigInteger is
/// resized to zero.
/// @param	value	the value the short BigInteger must be set to.
/// @return	0 (to be able to call and return).
size_t BigInteger::SetShort(digit_t value) {
	if (value == 0) resize(0);
	else {
		resize(1);
		digits[0] = value;
	}
	return 0;
}

/*=================================================================================================*/
/// @brief Set the current BigInteger equal to another BigInteger. 
/// @details Afterward, both objects have the same size
/// and all of theirs digits are also the same.
/// @param	obj	The BigInteger the current BigInteger must be set to.
void BigInteger::SetEqual(const BigInteger &obj) {
	if (&obj == this) return;
	resize(obj.size());
	for (size_t i = 0; i < obj.size(); i++) digits[i] = obj.digits[i];
}

/*****************************************/
/* DIGITS SIZE/ADJUST                    */
/*****************************************/

/*=================================================================================================*/
/// @brief Returns number of significant digits in the current BigInteger.
/// @details meaning the highest non
/// zero digit index. Consequently, the method return the minimum number of digits a BigInteger
/// can be resized to without changing its value. This value is 0 is all digits are zeros.
/// @remark the size of a BigInteger is the storage size used by it.
/// @return	largest significant digits of a BigInteger.
digitsize_t BigInteger::Sizeof() const {
	size_t ndigits = digits.size();
	if (ndigits == 0) return digitsize_t(0);
	while (ndigits--) {
		if (digits[ndigits] != 0) return digitsize_t(++ndigits);
	}
	return digitsize_t(0);
}

/*=================================================================================================*/
/// @brief Adjust the number of digits of a BigInteger to the minimal storage size needed to store
/// its value.
/// @details meaning all its most significant digits equal to zero are discarded.
/// @return	the number of digits is the resized BigInteger. Can be zero if all digits are zeros.
size_t BigInteger::AdjustSize() {
	size_t ndigits = Sizeof();
	digits.resize(ndigits);
	return ndigits;
}

/*=================================================================================================*/
/// @brief Return the index of the first non null MSB of a BigInteger. 
/// @details Can also be interpreted as the minimum number of bits the BigInteger can be 
/// 		stored into without changing its value.
/// @return	the minimum storage length of the BigInteger in bits.
bitsize_t BigInteger::BitLength() const {
	if (size() == 0) return 0_bits;
	const BigInteger &d = *this;
	size_t n = d.Sizeof();
	if (n == 0) return 0_bits;

	size_t		i = 0;
	for (uint32_t mask = digit_t::HiBitMask; mask > 0; mask >>= 1, i++) {
		if (d[n - 1] & mask) break;
	}
	size_t bits = n * digit_t::BitSize - i;
	return bitsize_t(bits);
}

bytesize_t BigInteger::ByteLength() const {
	if (size() == 0) return 0_bytes;
	// const BigInteger &d = *this;
	size_t n = Sizeof();
	if (n == 0) return 0_bytes;
	uint32_t LastDigit = digits[n - 1];
	n *= digit_t::ByteSize;
	if (LastDigit & 0xff000000) return bytesize_t(n);
	if (LastDigit & 0x00ff0000) return bytesize_t(n - 1);
	if (LastDigit & 0x0000ff00) return bytesize_t(n - 2);
	return bytesize_t(n - 3);
}

/************************/
/* CONVERSION FUNCTIONS */
/************************/

uint8_t SwapByte(uint8_t v) {
	return uint8_t((v << 4) | (v >> 4));
}

template <class T> struct divide_t {
	T	quotient, remainder;  // quotient, remainder
};

template <class T> divide_t<T> IntDiv(const T &a, const T &b) {
	return divide_t<T>({ a / b,a%b });
}

/*=================================================================================================*/
/// @brief Internal function used to convert a decimal character to its integer equivalent
/// @param	c	The decimal character to convert from.
/// @return	the integer represented by c.
static uint32_t CharToDecimal(char c) {
	if (c >= '0' && c <= '9') return uint32_t(c - '0');
	else return uint32_t(-1);
}

/*=================================================================================================*/
/// @brief Internal function used to convert an hexadecimal character to its integer equivalent
/// @param	c	The hexadecimal character to convert from.
/// @return	the integer represented by c.
static uint32_t CharToHexa(char c) {
	if (c >= '0' && c <= '9') return uint32_t(c - '0');
	else if (c >= 'a' && c <= 'f') return uint32_t(c - 'a' + 10);
	else if (c >= 'A' && c <= 'F') return uint32_t(c - 'A' + 10);
	else return uint32_t(-1);
}

/*=================================================================================================*/
/// @brief Initializes a BigInteger from an array of bytes. 
/// @details The array is copied in the BigInteger
/// in same order (0 = the least significant byte). The BigInteger is resized if needied.
/// @param	octets the vector of Bytes to use.
/// @return	the size of the BigInteger initialized.
size_t BigInteger::ConvFromOctets(const std::vector<uint8_t> &octets) {
	// BigInteger &u = *this;
	size_t noctets = octets.size();
	size_t ndigits = DivUp(noctets, digit_t::ByteSize), nbytes = ndigits*digit_t::ByteSize;
	size_t nleft = ndigits * digit_t::ByteSize - noctets;
	resize(ndigits);
	if (ndigits == 0) return 0;
	uint8_t			*Dst = reinterpret_cast<uint8_t*>(data()) + nbytes - 1;
	const uint8_t	*Src = octets.data();
	// for (size_t i = 0; i < noctets; i++, Src++) Dst[i] = SwapByte(*Src);
	for (size_t i = 0; i < nleft; i++, Dst--) *Dst = 0;
	for (size_t i = 0; i < noctets; i++, Src++, Dst--) *Dst = *Src;
	return ndigits;
}

/*=================================================================================================*/
/// @brief Converts a BigInteger to an array of bytes. 
/// @details The array is copied from the BigInteger
/// in same order (0 = the least significant byte). The output vector is resized if needed.
/// @param octets	the output array of bytes.
/// @return	the size of the vector of bytes.
size_t BigInteger::ConvToOctets(std::vector<uint8_t> &octets) const {
	// const BigInteger &b = *this;
	octets.clear();
	if (isZero()) octets.push_back(0);
	else {
		size_t   i = size() - 1;
		// skip zero digits
		while (digits[i] == 0) i--;
		// skip zero bytes in first non null digit
		digit_t::raw   v = { digits[i] };
		int k = 3;
		while (v.byte[k] == 0) k--;
		for (; k >= 0; k--) octets.push_back(v.byte[k]);
		while (1) {
			if (i == 0) break;
			i--;
			v.digit = digits[i];
			for (int k = 3; k >= 0; k--) octets.push_back(v.byte[k]);
		};
	}
	return octets.size();
}

/*=================================================================================================*/
/// @brief convert a string containing a decimal number into the equivalent BigInteger.
/// @param decimal		string containing the decimal number to be converted.
/// @return	The size of the created BigInteger.
size_t BigInteger::ConvFromDecimal(const std::string &decimal) {
	size_t  len = decimal.length(), imax, i = 0;
	BigInteger  r1, r2;
	r1.zero();
	do {
		uint32_t  val = 0, base = 1;
		imax = std::min(len - 1, i + 8);
		for (; i <= imax; ++i) {
			val = 10 * val + CharToDecimal(decimal[i]);
			base *= 10;
		}
		r2.ShortMult(r1, base);
		r1.ShortAdd(r2, val);
		i = imax + 1;
	} while (i < len);
	swap(r1);
	return size();
}

/*=================================================================================================*/
/// @brief convert a BigInteger to the equivalent decimal, and stored as a string.
/// @param decimal		Output string containing the converted BigInteger.
/// @return	The size of the decimal string.
size_t BigInteger::ConvToDecimal(std::string &decimal) const {
	const char *DecDigits = "0123456789";
	const uint32_t   base = 1000000000; // biggest 10^p number in a digit
	if (isZero()) decimal = "0";
	else {
		decimal.clear();
		// convert		
		BigInteger  q0 = *this, q1;
		uint32_t	r, r10;
		do {
			r = q1.ShortDiv(q0, base);
			for (size_t i = 0; i < 9; i++) {
				r10 = r % 10;
				decimal.push_back(DecDigits[r10]);
				r /= 10;
			}
			q0.swap(q1);
		} while (!q0.isZero());
		while (decimal.back() == '0') decimal.pop_back();
		std::reverse(decimal.begin(), decimal.end());
	}
	return decimal.size();
}

/*=================================================================================================*/
/// convert a string containing an hexadecimal number into the equivalent BigInteger.
/// @param hexa		string containing the hexadecimal number to be converted.
/// @return	The size of the created BigInteger.
size_t BigInteger::ConvFromHex(const std::string &hexa) {
	size_t  len = hexa.length();
	if (len == 0) return SetShort(0);
	divide_t<size_t>  res = IntDiv<size_t>(len, digit_t::OctalSize);
	size_t	nDigits = res.quotient + (res.remainder ? 1 : 0);
	size_t	iDigits = nDigits - 1, k = 0;
	resize(nDigits);
	// first digit: partial fill
	uint32_t val = 0;
	size_t   imax = (res.remainder ? res.remainder : digit_t::OctalSize);
	for (size_t j = 0; j < imax; ++j, ++k)
		val = (val << 4) | CharToHexa(hexa[k]);
	digits[iDigits] = val;
	// last digits: complete fill
	while (1) {
		if (iDigits == 0) break;
		iDigits--;
		val = 0;
		for (size_t j = 0; j < digit_t::OctalSize; ++j, ++k)
			val = (val << 4) | CharToHexa(hexa[k]);
		digits[iDigits] = val;
	}
	AdjustSize();
	return size();
}

/*=================================================================================================*/
/// @brief convert a BigInteger to the equivalent hexadecimal, and stored as a string.
/// @param hexa		Output string containing the converted BigInteger.
/// @return	The size of the hexadecimal string.
size_t BigInteger::ConvToHex(std::string &hexa) const {
	const char *HexaDigits = "0123456789abcdef";
	auto push = [HexaDigits](std::string &vec, uint8_t val) {
		vec.push_back(HexaDigits[val >> 4]);
		vec.push_back(HexaDigits[val & 0x0f]);
	};
	hexa.clear();
	if (isZero()) hexa.push_back('0');
	else {
		size_t   i = size() - 1;
		// skip zero digits
		while (digits[i] == 0) i--;
		// skip zero bytes in first non null digit
		digit_t::raw   v = { digits[i] };
		int k = 3;
		while (v.byte[k] == 0) k--;
		// skip zero octal in byte
		if ((v.byte[k] & 0xf0) == 0) hexa.push_back(HexaDigits[v.byte[k] & 0x0f]);
		else push(hexa, v.byte[k]);
		// next bytes
		for (--k; k >= 0; k--) push(hexa, v.byte[k]);
		// next digits
		while (1) {
			if (i == 0) break;
			i--;
			v.digit = digits[i];
			for (int k = 3; k >= 0; k--) push(hexa, v.byte[k]);
		};
	}
	return hexa.size();
}


/************************/
/* DISPLAY FUNCTIONS    */
/************************/

/*=================================================================================================*/
/// @brief View a BigInteger as an hexadecimal string.
/// @param	title		  	The title used to describe the BigInteger (can be null).
/// @param	eol			  	True to add an EOL at the end of the BigInteger output.
/// @param stream	The stream to write the output into.
void BigInteger::viewHex(const char *title, bool eol, std::ostream &stream) const {
	std::string str;
	ConvToHex(str);
	// std::reverse(str.begin(), str.end());
	if (title) stream << title << " ";
	for (size_t i = 0; i < str.length(); i++) {
		if ((str.length() - i) % 8 == 0) stream << " ";
		stream << str[i];
	}
	if (eol) stream << "\n";
}

/*=================================================================================================*/
/// @brief View a BigInteger as an decimal string.
/// @param	title		  	The title used to describe the BigInteger (can be null).
/// @param	eol			  	True to add an EOL at the end of the BigInteger output.
/// @param	sep			  	True to add a dot separator every 3 decimal digits.
/// @param stream	The stream to write the output into.
void BigInteger::viewDec(const char *title, bool eol, bool sep, std::ostream &stream) const {
	std::string str;
	ConvToDecimal(str);
	if (title) stream << title << " ";
	size_t len = str.length() - 1;
	for (size_t i = 0; i <= len; i++) {
		if (str[i] != ' ') {
			stream << str[i];
			if (sep && (i!=len) && ((len - i) % 3 == 0)) stream << ".";
		}
	}
	if (eol) stream << "\n";
}

/*****************************************/
/* BINARY OPERATIONS                     */
/*****************************************/

/*=================================================================================================*/
/// @brief internal method used computes a left shift (a = b << s)
/// @details assume the current BigInteger is correctly resized.
/// @param b	The BigInteger to shift left.
/// @param	shift	 	The number of bit the BigInteger must be shifted.
/// @return	the carry.

digit_t BigInteger::_ShiftLeft(const BigInteger &b, size_t shift) {
	BigInteger &a = *this;
	size_t ndigits = size();
	/* Computes a = b << shift */
	/* Modified to cope with shift > BITS_PERDIGIT */
	//LOG("shift=%d a.ndigits=%d b.ndigits=%d", shift, size(), b.size());

	/* Do we shift whole digits? */
	size_t	  bits;
	if (shift >= digit_t::BitSize) {
		LOG("shift >= BITS_PER_DIGIT");
		size_t  nw = shift / digit_t::BitSize;
		size_t  i = ndigits;
		while (i--) a[i] = (i >= nw ? b[i - nw] : 0);
		/* Call again to shift bits inside digits */
		bits = shift % digit_t::BitSize;
		uint32_t  carry = b[ndigits - nw] << bits;
		if (bits) carry |= a._ShiftLeft(a, bits);
		return carry;
	}
	else {
		bits = shift;
	}
	/* Construct mask = high bits set */
	{
		uint32_t  mask = ~(~(uint32_t)0 >> bits);			//LOG("mask: %u", mask);
		size_t    y = digit_t::BitSize - bits;
		uint32_t  carry = 0;
		for (size_t i = 0; i < ndigits; i++) {
			uint32_t nextcarry = (b[i] & mask) >> y;
			a[i] = b[i] << bits | carry;
			carry = nextcarry;
			//TRACE(a.viewHex("shift a"));
		}
		return carry;
	}
}

/*=================================================================================================*/
/// @brief computes a left shift (a = b << s)
/// @param b	The BigInteger to shift left.
/// @param	shift	 	The number of bit the BigInteger must be shifted.
void BigInteger::ShiftLeft(const BigInteger &b, size_t shift) {
	BigInteger &a = *this;
	// size_t ndigits = size();
	/* Increases the size of a if necessary. */
	/* modified to allow any size of shift */
	size_t dig_size = b.size();
	if (shift >= digit_t::BitSize) dig_size += (shift / digit_t::BitSize);
	/* Assume overflow */
	dig_size++;
	/* Make sure both big enough */
	a.resize(dig_size);
	b.resize(dig_size);
	/* Left shift */
	a._ShiftLeft(b, shift);
	/* Set the final size */
	a.AdjustSize();
}

/*=================================================================================================*/
/// @brief internal method used computes a right shift (a = b >> s)
/// assume the current BigInteger is correctly resized.
/// @param b	The BigInteger to shift right.
/// @param	shift	 	The number of bit the BigInteger must be shifted.
/// @return	the carry (can be ignored).
digit_t BigInteger::_ShiftRight(const BigInteger &b, size_t shift) {
	BigInteger &a = *this;
	size_t ndigits = size();
	/* Computes a = b >> shift */
	/* Modified to cope with shift > BITS_PERDIGIT */

	/* Do we shift whole digits? */
	size_t  bits;
	if (shift >= digit_t::BitSize) {
		size_t nw = shift / digit_t::BitSize;
		for (size_t i = 0; i < ndigits; i++)
			a[i] = ((i + nw) < ndigits ? b[i + nw] : 0);
		/* Call again to shift bits inside digits */
		bits = shift % digit_t::BitSize;
		uint32_t  carry = b[nw - 1] >> bits;
		if (bits) carry |= a._ShiftRight(a, bits);
		return carry;
	}
	else bits = shift;

	/* Construct mask to set low bits */
	{
		uint32_t  mask = ~(~(uint32_t)0 << bits);
		size_t    y = digit_t::BitSize - bits;
		uint32_t  carry = 0; // was size_t
		size_t    i = ndigits;
		while (i--) {
			uint32_t nextcarry = (b[i] & mask) << y;
			a[i] = b[i] >> bits | carry;
			carry = nextcarry;
		}
		return carry;
	}
}

/*=================================================================================================*/
/// @brief computes a right shift (a = b >> s)
/// @param b	The BigInteger to shift right.
/// @param	shift	 	The number of bit the BigInteger must be shifted.
void BigInteger::ShiftRight(const BigInteger &b, size_t shift) {
	BigInteger &a = *this;
	// size_t ndigits = size();
	/* Throws away shifted bits */
	/* modified to allow any size of shift */
	size_t dig_size = b.size();
	a.resize(dig_size);
	/* Right shift */
	a._ShiftRight(b, shift);
	/* Set the final size */
	a.AdjustSize();
}

/*****************************************/
/* FUNCTIONS WITH A SINGLE (SHORT) DIGIT */
/*****************************************/

/*=================================================================================================*/
/// @brief Multiply a BigInteger by a digit (i.e. short BigInteger), and store the result in
/// the current BigInteger.
/// @param	U	The BigInteger to be multiplied.
/// @param	v	The digit to multiply for.
/// @return	0 (to be able to call and return).

uint32_t BigInteger::ShortMult(const BigInteger &U, const digit_t &v) {
	// managing re-entering first argument by copying it if needed
	// BigIntegerAuto  u((&U == this), U);
	BigInteger _U;
	if (&U == this) _U = U;
	const BigInteger &u = (&U == this ? _U : U);

	BigInteger		&w = *this;
	size_t	   ndigits = u.size();
	if (ndigits == 0 || v == 0) w.digits.resize(0);
	else {
		/*	Computes product w = u * v
		Returns overflow k
		where w, u are multiprecision integers of ndigits each
		and v, k are single precision digits

		Ref: Knuth Algorithm M.
		*/
		w.digits.resize(ndigits + 1);
		w.zero();
		uint32_t overflow = 0, t[2];
		for (size_t j = 0; j < ndigits; j++) {
			/* t = x_i * v */
			hwMultiply(t, u[j], v);
			/* w_i = LOHALF(t) + carry */
			w[j] = t[0] + overflow;
			/* Overflow? */
			if (w[j] < overflow) t[1]++;
			/* Carry forward HIHALF(t) */
			overflow = t[1];
		}
		if (overflow) w[ndigits] = overflow;
		else w.AdjustSize();
	}
	return 0;
}

/*=================================================================================================*/
/// @brief Add a BigInteger and a digit (i.e. short BigInteger), and store the result in
/// the current BigInteger.
/// @remark the carry is stored is the result and is provided to inform the original BigInteger 
/// 		would have been resized.
/// @param	u	The BigInteger to be multiplied.
/// @param	v	The digit to multiply for.
/// @return	the carry if one exists (can be ignored).

uint32_t BigInteger::ShortAdd(const BigInteger &u, const digit_t &v) {
	BigInteger &w = *this;
	if (u.size() == 0) u.resize(1);
	// size_t ndigits = u.size();
	size_t dig_size = std::max<size_t>(u.size(), 1);
	w.resize(dig_size + 1);

	/*	Calculates w = u + v
	where w, u are multiprecision integers of ndigits each
	and v is a single precision digit.
	Returns carry if overflow.

	Ref: Derived from Knuth Algorithm A.
	*/
	/* Add v to first digit of u */
	w[0] = u[0] + v;
	uint32_t carry = (w[0] < v ? 1 : 0);

	/* Add carry to subsequent digits */
	for (size_t j = 1; j < dig_size; j++) {
		w[j] = u[j] + carry;
		carry = (w[j] < carry ? 1 : 0);
	}

	/* Cope with overflow */
	if (carry) w[dig_size] = carry;
	else w.resize(dig_size);

	return uint32_t(carry);
}


/*=================================================================================================*/
/// @brief Subtract a digit (i.e. short BigInteger) from a BigInteger, and store the result in
/// the current BigInteger.
/// @remark the result is inadequate if u<v as a BigInteger cannot store a negative number.
/// @param	u	The BigInteger from which the digit must be subtracted.
/// @param	v	The digit to subtract.
/// @return	1 if u < v, 0 otherwise.

uint32_t BigInteger::ShortSub(const BigInteger &u, const digit_t &v) {
	if (u.isZero()) return zero();

	BigInteger	 &w = *this;
	size_t ndigits = u.size();
	size_t dig_size = std::max<size_t>(u.size(), 1);
	w.resize(dig_size);

	/*	Calculates w = u - v
	where w, u are multiprecision integers of ndigits each
	and v is a single precision digit.
	Returns borrow: 0 if u >= v, or 1 if v > u.

	Ref: Derived from Knuth Algorithm S.
	*/
	/* Subtract v from first digit of u */
	w[0] = u[0] - v;
	uint32_t borrow = (w[0] > digit_t::MaxValue - v ? 1 : 0);

	/* Subtract borrow from subsequent digits */
	for (size_t j = 1; j < ndigits; j++) {
		w[j] = u[j] - borrow;
		borrow = (w[j] > digit_t::MaxValue - borrow ? 1 : 0);
	}
	return borrow;
}


/*=================================================================================================*/
/// @brief Divide a BigInteger by a digit (i.e. short BigInteger), and store the result  (u/d) in
/// the current BigInteger.
/// @remark the result is inadequate if u<v as a BigInteger cannot store a negative number.
/// @param	U	The BigInteger to divided.
/// @param	D	The digit by which the BigInteger is divided.
/// @return	the remainder of the division (= u mod d).
digit_t BigInteger::ShortDiv(const BigInteger &U, digit_t D) {
	// managing re-entering first argument by copying it if needed
	// BigIntegerAuto u(&U == this, U);
	BigInteger _U;
	if (&U == this) _U = U;
	const BigInteger &u = (&U == this ? _U : U);

	BigInteger	   &q = *this;
	uint32_t	   &d = D.value;
	size_t    ndigits = u.size();
	size_t    dig_size = u.size();
	q.resize(dig_size);
	/*	Calculates quotient q = u div v
	Returns remainder r = u mod v
	where q, u are multiprecision integers of ndigits each
	and r, v are single precision digits.

	Makes no assumptions about normalisation.
	Ref: Knuth Vol 2 Ch 4.3.1 Exercise 16 p625
	*/
	if (ndigits == 0) return 0;
	if (d == 0)	return 0;	/* Divide by zero error */
							/*	Normalise first */
							/*	Requires high bit of V
							to be set, so find most signif. bit then shift left,
							i.e. d = 2^shift, u' = u * d, v' = v * d.
							*/
	size_t   shift = 0;
	for (uint32_t bitmask = digit_t::HiBitMask; shift < digit_t::BitSize; shift++) {
		if (d & bitmask) break;
		bitmask >>= 1;
	}
	d <<= shift;
	uint32_t overflow = q._ShiftLeft(u, shift);
	BigInteger uu = q;
	/* Step S1 - modified for extra digit. */
	uint32_t t[2], r = overflow;	/* New digit Un */
	size_t j = ndigits;
	while (j--) {
		/* Step S2. */
		t[1] = r;
		t[0] = uu[j];
		overflow = hwDivide(q[j], r, t, d);
	}

	/* Unnormalise */
	r >>= shift;
	return r;
}

/*=================================================================================================*/
/// @brief Compute the modulo of the current BigInteger by a digit (i.e. short BigInteger),
/// and return the result.
/// @param	m	The digit used as the divisor.
/// @return	the remainder of the division by m.
digit_t BigInteger::ShortMod(digit_t m) {
	/*	Calculates r = a mod d
	where a is a multiprecision integer of ndigits
	and r, d are single precision digits.
	Use remainder from divide function.
	*/
	BigInteger	 &a = *this;
	BigInteger   q;
	return   q.ShortDiv(a, m);
}

/*=================================================================================================*/
/// @brief internal function returning true if Qhat is too big
/// i.e. if (Qhat * Vn - 2) > (b.Rhat + Uj + n - 2).
/// @param	qhat	The value of Qhat.
/// @param	rhat	The value of Rhat.
/// @param	vn2 	The value of Vn - 2.
/// @param	ujn2	The value of Uj + n - 2.
/// @return	1 if Qhat is too big, 0 otherwise.

static int QhatTooBig(digit_t qhat, digit_t rhat, digit_t vn2, digit_t ujn2) {
	uint32_t t[2];
	hwMultiply(t, qhat, vn2);
	if (t[1] < rhat) return 0;
	else if (t[1] > rhat) return 1;
	else if (t[0] > ujn2) return 1;
	return 0;
}

/*****************************************/
/* Internal vectors computations         */
/*****************************************/

/*=================================================================================================*/
/// @brief Internal function to compute the addition of two raw vectors of digits of
/// size ndigits. Assume u,v and w have the correct size (not checked).
/// @param  w	the raw vector containing the result of the addition u+v.
/// @param	u	the first raw vector u.
/// @param	v	he first raw vector v.
/// @param	ndigits  	the number of ndigits in each raw vectors.
/// @return	the carry of u+v that cannot be stored in w.
uint32_t VectorAdd(uint32_t *w, const uint32_t *u, const uint32_t *v, size_t ndigits) {
	/*	Calculates w = u + v
	where w, u, v are multiprecision integers of ndigits each
	Returns carry if overflow. Carry = 0 or 1.

	Ref: Knuth Vol 2 Ch 4.3.1 p 266 Algorithm A.
	*/

	/* Step A1. Initialise */
	uint32_t carry = 0;
	for (size_t j = 0; j < ndigits; j++) {
		/*	Step A2. Add digits w_j = (u_j + v_j + k)
		Set k = 1 if carry (overflow) occurs
		*/
		w[j] = u[j] + carry;
		carry = (w[j] < carry ? 1 : 0);
		w[j] += v[j];
		if (w[j] < v[j]) carry++;

	}	/* Step A3. Loop on j */
	return carry;
}


/*=================================================================================================*/
/// @brief Internal function to compute  w = w - q.v, where w and v are two raw vectors of
/// n ndigits, and q a single digit. wn is the MSB w stored separately.
/// @param wn	the most significant digit of w stored.
/// @param w	the raw vector w.
/// @param v	the raw vector v.
/// @param q	the digit q.
/// @param n	the size of the raw vectors w and v.
/// @return	the new value of wn.

static uint32_t VectorMultSub(uint32_t wn, uint32_t *w, const uint32_t *v, uint32_t q, size_t n) {
	if (q == 0)	return wn; /* No change */
	uint32_t  k = 0, t[2];
	for (size_t i = 0; i < n; i++) {
		hwMultiply(t, q, v[i]);
		//printf("i:%d t=[%x %x] q=%x v[i]=%x k=%x w[i]=%x\n", i, t[0], t[1], q, v[i], k, w[i]);
		w[i] -= k;
		k = (w[i] > digit_t::MaxValue - k ? 1 : 0);
		w[i] -= t[0];
		if (w[i] > digit_t::MaxValue - t[0]) k++;
		k += t[1];
		//printf("i:%d k=%x w[i]=%x\n", i, k, w[i]);
	}
	/* Cope with Wn not stored in array w[0..n-1] */
	wn -= k;
	return wn;
}

/************************/
/* ARITHMETIC FUNCTIONS */
/************************/

/*=================================================================================================*/
/// @brief compute the sum of two BigInteger u+v and store the result in the current BigInteger.
/// @remark 
/// 	- the inputs size are extended such as they are identical.  
/// 	- the output is resized to store the result.
/// 	- the carry is stored in the result.  
/// @param u	first BigInteger u.
/// @param V	second BigInteger v.
/// @return	the carry of one arise (can be ignored).

uint32_t BigInteger::Add(const BigInteger &u, const BigInteger &V) {
	// managing re-entering first argument by copying it if needed
	// BigIntegerAuto  v(&V == this, V);
	BigInteger _V;
	if (&V == this) _V = V;
	const BigInteger &v = (&V == this ? _V : V);

	BigInteger		&w = *this;
	// size_t	ndigits = size();
	// w.zero();
	/* Check for cheaper option */
	if (v.size() == 1) return ShortAdd(u, v[0]);

	/* Make sure u and v are the same size */
	size_t dig_size = std::max(u.size(), v.size());
	v.resize(dig_size);
	u.resize(dig_size);
	/* Now make sure w is big enough for sum (incl carry) */
	w.resize(dig_size + 1);
	w.zero(dig_size);

	/*	Calculates w = u + v */
	uint32_t carry = VectorAdd(w.data(), u.data(), v.data(), dig_size);

	/* Make sure we've set the right size for w */
	if (carry) w[dig_size] = carry;
	else w.AdjustSize();

	return carry;
}

/*=================================================================================================*/
/// @brief compute the difference of two BigInteger u-v and store the result in the current BigInteger.
/// @remark 
/// 	- the inputs size are extended such as they are identical.  
/// 	- the output is resized to store the result.
/// 	- the difference is not computed if v>u (and return 1).
/// @param u	first BigInteger u.
/// @param V	second BigInteger v.
/// @return	1 of v>u or 0 is the difference can be computed.

uint32_t BigInteger::Subtract(const BigInteger &u, const BigInteger &V) {
	// managing re-entering first argument by copying it if needed
	// BigIntegerAuto   v(&V == this, V);
	BigInteger _V;
	if (&V == this) _V = V;
	const BigInteger &v = (&V == this ? _V : V);

	BigInteger		 &w = *this;
	size_t	ndigits = size();
	/* Check for cheaper option */
	if (v.size() == 1) return ShortSub(u, v[0]);

	/* Make sure u and v are the same size */
	size_t dig_size = std::max(u.size(), v.size());
	u.resize(dig_size);
	v.resize(dig_size);
	w.resize(dig_size);
	w.zero(dig_size);
	ndigits = dig_size;

	/*	Calculates w = u - v where u >= v
	w, u, v are multiprecision integers of ndigits each
	Returns 0 if OK, or 1 if v > u.

	Ref: Knuth Vol 2 Ch 4.3.1 p 267 Algorithm S.
	*/
	/* Step S1. Initialise */
	uint32_t  borrow = 0;
	for (size_t j = 0; j < ndigits; j++) {
		/*	Step S2. Subtract digits w_j = (u_j - v_j - k)
		Set k = 1 if borrow occurs.
		*/
		w[j] = u[j] - borrow;
		borrow = (w[j] > digit_t::MaxValue - borrow ? 1 : 0);
		w[j] -= v[j];
		if (w[j] > digit_t::MaxValue - v[j]) borrow++;
	}	/* Step S3. Loop on j */

		/* Borrow should be zero if u >= v */
	w.AdjustSize();
	return borrow;
}

/*=================================================================================================*/
/// @brief compute the multiplication of two BigInteger u*v and store the result in the current
/// BigInteger.
/// @remark 
/// 	- the inputs size are extended such as they are identical.  
/// 	- the output is resized to be big enough to store the result.
/// @param U	first BigInteger u.
/// @param V	second BigInteger v.
/// @return	0 (the result can always be computed).

uint32_t BigInteger::Multiply(const BigInteger &U, const BigInteger &V) {
	// managing re-entering first argument by copying it if needed
	// BigIntegerAuto   u(&U == this, U);
	// BigIntegerAuto   v(&V == this, V);
	BigInteger _U;
	if (&U == this) _U = U;
	const BigInteger &u = (&U == this ? _U : U);

	BigInteger _V;
	if (&V == this) _V = V;
	const BigInteger &v = (&V == this ? _V : V);

	/* Check for cheaper option */
	switch (v.size()) {
	case 0: return zero();
	case 1: ShortMult(u, v[0]);
	}
	switch (u.size()) {
	case 0: return zero();
	case 1: ShortMult(v, u[0]);
	}
	//if (u.isZero()) return zero();
	//if (v.isZero()) return zero();

	/* Make sure u and v are the same size */
	BigInteger &w = *this;
	size_t ndigits = std::max(u.size(), v.size());
	u.resize(ndigits);
	v.resize(ndigits);
	/* Now make sure w is big enough for product */
	w.resize(2 * ndigits);
	/*	Computes product w = u * v
	where u, v are multiprecision integers of ndigits each
	and w is a multiprecision integer of 2*ndigits
	Ref: Knuth Vol 2 Ch 4.3.1 p 268 Algorithm M.
	*/
	size_t    m = ndigits, n = ndigits;
	uint32_t  t[2];
	/* Step M1. Initialise */
	// for (size_t i = 0; i < 2 * m; i++) w[i] = 0;
	w.zero();
	for (size_t j = 0; j < n; j++) {
		/* Step M2. Zero multiplier? */
		if (v[j] == 0) w[j + m] = 0;
		else {
			/* Step M3. Initialise i */
			uint32_t  k = 0;
			for (size_t i = 0; i < m; i++) {
				/* Step M4. Multiply and add */
				/* t = u_i * v_j + w_(i+j) + k */
				hwMultiply(t, u[i], v[j]);
				t[0] += k;
				if (t[0] < k) t[1]++;
				t[0] += w[i + j];
				if (t[0] < w[i + j]) t[1]++;
				w[i + j] = t[0];
				k = t[1];
			}
			/* Step M5. Loop on i, set w_(j+m) = k */
			w[j + m] = k;
		}
	}	/* Step M6. Loop on j */
	w.AdjustSize();
	return 0;
}


/*=================================================================================================*/
/// @brief compute the division of two BigInteger u/v and store the quotient in the current 
/// BigInteger, and the remainder in another BigInteger r.
/// @warning u must be different than this.
/// @remark 
/// 	- the inputs size are extended such as they are identical.  
/// 	- the output is resized to be big enough to store the result.  
/// @param r	the BigInteger remainder r.
/// @param U	the first BigInteger u.
/// @param V	the second BigInteger v.
/// @return	0 (the result can always be computed).

uint32_t BigInteger::Divide(BigInteger &r, const BigInteger &U, const BigInteger &V) {
	assert(&r != this && "Quotient and Remainder must be different");
	// managing re-entering first argument by copying it if needed
	//BigIntegerAuto   u(&U == this,U);
	//BigIntegerAuto   v(&V == this, V);

	BigInteger _U;
	if (&U == this) _U = U;
	const BigInteger &u = (&U == this ? _U : U);

	BigInteger v = V;

	BigInteger	&q = *this;
	size_t dig_size = u.size();
	q.resize(dig_size);
	r.resize(dig_size);

	/*	Computes quotient q = u / v and remainder r = u mod v
	where q, r, u are multiple precision digits
	all of udigits and the divisor v is vdigits.

	Ref: Knuth Vol 2 Ch 4.3.1 p 272 Algorithm D.

	Do without extra storage space, i.e. use r[] for
	normalised u[], unnormalise v[] at end, and cope with
	extra digit Uj+n added to u after normalisation.

	WARNING: this trashes q and r first, so cannot do
	u = u / v or v = u mod v.
	It also changes v temporarily so cannot make it const.
	*/

	/* Clear q and r */
	q.zero();   // q=0
	r.zero();   // r=0

				/* Work out exact sizes of u and v */
	size_t n = v.Sizeof();
	size_t m = u.Sizeof();
	if (m == 0) return 0; // u is zero
						  // exact size when shift
	v.resize(n);
	u.resize(m);
	r.resize(m);

	/* Catch special cases */
	if (n == 0) return uint32_t(-1);	/* Error: divide by zero */
	if (n == 1) {	/* Use short division instead */
		r[0] = q.ShortDiv(u, v[0]);
		return 0;
	}

	if (m < n) { /* v > u, so just set q = 0 and r = u */
		r.SetEqual(u);
		return 0;
	}

	if (m == n) { /* u and v are the same length */
		int cmp = Compare(u, v);
		if (cmp < 0) {
            /* v > u, as above */
            r.SetEqual(u);
            return 0;
        }
		else if (cmp == 0) {
            /* v == u, so set q = 1 and r = 0 */
            q.SetDigit(1);
            return 0;
        }
	}
    m -= n;

	/*	In Knuth notation, we have:
	Given
	u = (Um+n-1 ... U1U0)
	v = (Vn-1 ... V1V0)
	Compute
	q = u/v = (QmQm-1 ... Q0)
	r = u mod v = (Rn-1 ... R1R0)
	*/

	/*	Step D1. Normalise */
	/*	Requires high bit of Vn-1
	to be set, so find most signif. bit then shift left,
	i.e. d = 2^shift, u' = u * d, v' = v * d.
	*/
	size_t shift = 0;
	for (size_t bitmask = digit_t::HiBitMask; shift < digit_t::BitSize; shift++) {
		if (v[n - 1] & bitmask) break;
		bitmask >>= 1;
	}

	/* Normalise v in situ - NB only shift non-zero digits */
	uint32_t overflow = v._ShiftLeft(v, shift);
	/* Copy normalised dividend u*d into r */
	overflow = r._ShiftLeft(u, shift);

	uint32_t *uu = r.data();	/* Use ptr to keep notation constant */
	uint32_t qhat, rhat, t[2];
	t[0] = overflow;	/* Extra digit Um+n */

	/* Step D2. Initialise j. Set j = m */
	//for (size_t j = m; j >= 0; j--)
	size_t j = m+1;
	do {
		j--;

		/* Step D3. Set Qhat = [(b.Uj+n + Uj+n-1)/Vn-1]
		and Rhat = remainder */
		int qhatOK = 0;
		t[1] = t[0];	/* This is Uj+n */
		t[0] = uu[j + n - 1];
		overflow = hwDivide(qhat, rhat, t, v[n - 1]);

		/* Test Qhat */
		if (overflow) {	/* Qhat == b so set Qhat = b - 1 */
			qhat = digit_t::MaxValue;
			rhat = uu[j + n - 1];
			rhat += v[n - 1];
			if (rhat < v[n - 1]) qhatOK = 1; /* Rhat >= b, so no re-test */
		}
		/* [VERSION 2: Added extra test "qhat && "] */
		if (qhat && !qhatOK && QhatTooBig(qhat, rhat, v[n - 2], uu[j + n - 2]))
		{	/* If Qhat.Vn-2 > b.Rhat + Uj+n-2
			decrease Qhat by one, increase Rhat by Vn-1
			*/
			qhat--;
			rhat += v[n - 1];
			/* Repeat this test if Rhat < b */
			if (!(rhat < v[n - 1]))
				if (QhatTooBig(qhat, rhat, v[n - 2], uu[j + n - 2]))
					qhat--;
		}


		/* Step D4. Multiply and subtract */
		uint32_t *ww = &uu[j];
		overflow = VectorMultSub(t[1], ww, v.data(), qhat, (size_t)n);

		/* Step D5. Test remainder. Set Qj = Qhat */
		q[j] = qhat;
		if (overflow)
		{	/* Step D6. Add back if D4 was negative */
			q[j]--;
			overflow = VectorAdd(ww, ww, v.data(), (size_t)n);
		}

		t[0] = uu[j + n - 1];	/* Uj+n on next round */

	} while (j!=0);	/* Step D7. Loop on j */

	/* Clear high digits in uu */
	for (size_t j = n; j < m + n; j++) uu[j] = 0;

	/* Step D8. Unnormalise. */
	r.ShiftRight(shift);
	v.ShiftRight(shift);

	/* Set final sizes */
	q.AdjustSize();
	r.AdjustSize();

	return 0;
}


/*=================================================================================================*/
/// @brief  Computes the division of two BigInteger u/v and store the remainder in the current
/// BigInteger, and the actual quotient is discarded.
/// @remark 
/// 	- the inputs are resized such as they are identical.  
/// 	- the output is resized to be big enough to store the result.  
/// @param u	the first BigInteger u.
/// @param v	the second BigInteger v.
/// @return	0 (the result can always be computed).

uint32_t BigInteger::Modulo(const BigInteger &u, const BigInteger &v) {
	if (&u == this) {
		BigInteger r,q;
		q.Divide(r, u, v);
		swap(r);
	}
	else {
		BigInteger  &r = *this, q;
		q.Divide(r, u, v);
	}
	return 0;
}

/************************/
/* BIT-WISE OPERATIONS  */
/************************/
/* Set bit ibit (0..nbits-1) with value 1 or 0
-- increases size if a too small but does not shrink */

/*=================================================================================================*/
/// @brief  Sets the value of one bit in a BigInteger by index. 
/// @details If the index position exceed the BigInteger size, the BigInteger is 
/// 		 resized accordingly and then the bit is set.
/// @param	ibit 	the index of the bit (0=LSB).
/// @param	value	new value of the bit (0 means 0, anything else means 1).
/// @return	0.
uint32_t BigInteger::SetBit(size_t ibit, int value) { /// Set bit n of a (0..nbits-1) with value 1 or 0
	BigInteger	&a = *this;
	/* Which digit? (0-based) */
	size_t idigit = ibit / digit_t::BitSize;
	/* Check size */
	if (idigit >= size()) resize(idigit + 1);
	/* Set mask */
	size_t bit_to_set = ibit % digit_t::BitSize;
	uint32_t   mask = (0x01UL << bit_to_set) & digit_t::MaxValue;
	if (value) a[idigit] |= mask;
	else a[idigit] &= (~mask);
	/* Set the right size */
	AdjustSize();
	return 0;
}

/*=================================================================================================*/
/// @brief Gets the value of one bit in a BigInteger by index. If the index position exceed the
/// BigInteger size, return 0.
/// @param	ibit 	the index of the bit (0=LSB).
/// @return	return the value of the bit at the index position.

uint32_t BigInteger::GetBit(size_t ibit) const { ///Returns value 1 or 0 of bit n of a (0..nbits-1)
	const BigInteger	&a = *this;
	/* Which digit? (0-based) */
	size_t idigit = ibit / digit_t::BitSize;
	/* Check size */
	if (idigit >= size()) return 0;
	/* Set mask */
	size_t bit_to_get = ibit % digit_t::BitSize;
	uint32_t mask = (0x01UL << bit_to_get) & digit_t::MaxValue;
	return ((a[idigit] & mask) ? 1 : 0);
}

/*=================================================================================================*/
/// @brief  Compute the binary XOR of two BigIntegers.
/// @details The result is stored in the current BigInteger.
/// @param b	The first BigInteger u.
/// @param c	The second BigInteger v.

void BigInteger::XorBits(const BigInteger &b, const BigInteger &c) {	/// Computes bitwise operation a = b XOR c
	BigInteger	&a = *this;
	std::pair<const BigInteger&, const BigInteger&>
		v = (b.size() < c.size() ? std::make_pair(b, c) : std::make_pair(c, b));
	// resize the result to the biggest of both	
	a.resize(v.second.size());
	// do the business
	size_t  i = 0;
	for (; i < v.first.size(); i++)   a[i] = v.first[i] ^ v.second[i];
	for (; i < v.second.size(); i++) a[i] = v.first[i] ^ v.second[i];
	/* Set the final size */
	AdjustSize();
}

/*=================================================================================================*/
/// @brief Compute the binary OR of two BigIntegers.
/// @details The result is stored in the current BigInteger.
/// @param b	The first BigInteger u.
/// @param c	The second BigInteger v.

void BigInteger::OrBits(const BigInteger &b, const BigInteger &c) {	/// Computes bitwise operation a = b OR c
	BigInteger	&a = *this;
	std::pair<const BigInteger&, const BigInteger&>
		v = (b.size() < c.size() ? std::make_pair(b, c) : std::make_pair(c, b));
	// resize the result to the biggest of both	
	a.resize(v.second.size());
	// do the business
	size_t  i = 0;
	for (; i < v.first.size(); i++)   a[i] = v.first[i] | v.second[i];
	for (; i < v.second.size(); i++) a[i] = v.first[i] | v.second[i];
	/* Set the final size */
	AdjustSize();
}

/*=================================================================================================*/
/// @brief Compute the binary AND of two BigIntegers.
/// @details The result is stored in the current BigInteger.
/// @param b	The first BigInteger u.
/// @param c	The second BigInteger v.

void BigInteger::AndBits(const BigInteger &b, const BigInteger &c) {	/// Computes bitwise operation a = b AND c
	BigInteger	&a = *this;
	std::pair<const BigInteger&, const BigInteger&>
		v = (b.size() < c.size() ? std::make_pair(b, c) : std::make_pair(c, b));
	// resize the result to the biggest of both	
	a.resize(v.second.size());
	// do the business
	size_t  i = 0;
	for (; i < v.first.size(); i++)   a[i] = v.first[i] & v.second[i];
	for (; i < v.second.size(); i++) a[i] = v.first[i] & v.second[i];
	/* Set the final size */
	AdjustSize();
}

/*=================================================================================================*/
/// @brief Compute the binary NOT of a BigInteger.
/// @details The result is stored in the current BigInteger.
/// @param b	The BigInteger to flip.
void BigInteger::NotBits(const BigInteger &b) {	/// Computes bitwise a = NOT b (flip up to the MSB)
	BigInteger	&a = *this;
	/* Make sure all variables are the same size */
	size_t ndigits = b.size();
	a.resize(ndigits);
	/* Do the business */
	for (size_t i = 0; i <ndigits; i++) a[i] = ~b[i];
	/* Set the final size */
	AdjustSize();
}

/*=================================================================================================*/

