pour la compilation : make
pour l'exécution : ./prog_liste fichier_graphe.txt