/*
 * TONNELLE Nathan
 * 25-09-2020
*/

typedef enum COULEUR COULEUR;
enum COULEUR{
  BLANC,
  GRIS,
  NOIR
};