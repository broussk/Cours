/*
 * TONNELLE Nathan
 * 23-10-2020
*/

#ifndef ENSEMBLE_H
#define ENSEMBLE_H

typedef struct ensemble ensemble;
struct ensemble{

};

//créé un ensemble à partir d'un sommet x du graphe
//creer_ensemble(sommet)

//détermine l'ensemble auquel appartient le sommet x
//trouver_esemble(sommet)

//fusionne les ensembles dont font partie les sommet x et y
//union(sommet, sommet)

#endif //ENSEMBLE_H