pour la compilation : make
pour l'exécution : ./main