#include <iostream>
#include <cstdlib>

int
main(int argc, char** argv)
{
  int value;

  std::cout << value << std::endl;
  
  return EXIT_SUCCESS;
}
