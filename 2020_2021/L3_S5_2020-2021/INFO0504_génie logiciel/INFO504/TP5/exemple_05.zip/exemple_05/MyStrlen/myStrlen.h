#include <cstddef>

size_t mystrlen(const char *s);
