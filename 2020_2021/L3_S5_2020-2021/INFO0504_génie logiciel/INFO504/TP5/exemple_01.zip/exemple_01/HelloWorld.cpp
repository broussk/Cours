#include <cstdio>
#include <cstdlib>
#include <iostream>

int
main(int argc, char** argv)
{
  std::cout << "Hello World (what a marvelous message for a perfect example :-) )" << std::endl;
  return EXIT_SUCCESS;
}
