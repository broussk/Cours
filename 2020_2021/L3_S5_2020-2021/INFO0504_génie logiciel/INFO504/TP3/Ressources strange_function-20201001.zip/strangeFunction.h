#include <string.h>
#include <stdlib.h>

size_t strange_function (const char *str);
