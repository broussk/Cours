// prog.cpp

int main() {
	int u = fun(v) + incr(5);
}