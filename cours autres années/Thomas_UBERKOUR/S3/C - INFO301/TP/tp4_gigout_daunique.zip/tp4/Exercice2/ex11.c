#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>


int main (int argc, char *argv[]){
  srand(time(NULL));

  
  return 0;

}