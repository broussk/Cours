#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(){
  srand(time(NULL));
  //3)

  //2)
  // int x,mem = -1;
  // int T[20];
  // for(int i=0 ; i<20 ; i++){
  //   T[i]=rand()%(20);
  // }
  // printf("Entez un nombre : ");
  // scanf("%d",&x);
  // for(int i=0 ; i<20 ; i++){
  //   if(T[i]==x){
  //     if(mem==-1){
  //       mem = i;
  //     }
  //   }
  //   printf("%d. %d\n",(i+1),T[i]);
  // }
  // if(mem!=-1){
  //   printf("Première occurence de %d : case %d du tableau\n",x,mem+1);
  // }
  // else{
  //   printf("Pas d'occurence de %d dans le tableau\n",x);
  // }

  // 1)
  // int tab[20];
  // for(int i=0; i<20; i++){
  //   tab[i] = i;
  //   if(tab[i]%2==0){
  //     printf("%d\n",tab[i]);
  //   }
  // }
}
