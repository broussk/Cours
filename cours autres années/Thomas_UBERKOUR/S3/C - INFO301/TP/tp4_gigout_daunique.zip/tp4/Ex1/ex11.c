#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>


int main (int argc, char *argv[]){
  srand(time(NULL));

  char a[]="bonjour";
char b[]="Halo";
char c[]="";
  return 0;

}
