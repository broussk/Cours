void showTabInt(int *tab, int length);
