#include <stdlib.h>
#include <stdio.h>
#include "fonctions.h"
#include "utils.h"

int main(){
  // ex1p1();
  ex1p2();
  return 0;
}
