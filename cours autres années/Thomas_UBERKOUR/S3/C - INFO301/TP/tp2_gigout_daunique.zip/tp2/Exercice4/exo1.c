#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main (int argc, char *argv[]){

  //Exo 1 impossible ?


return 0;

}
