<?php
  public class FormFieldInput extends FormField{
    private $type;
    private $var;
    private $placeH;
    const TYPE_TEXT = "text";
    const TYPE_PWD = "password";

    public function __construct(string $id, string $nom, private $label, string $type, string $var, string $placeH){
      parent::__construct($id,$nom,$label);
      $this->var = $var;
      $this->placeH = $placeH;
      if(($type!=self::TYPE_TEXT)||($type!=self::TYPE_PWD)){
        $this->type = self::TYPE_TEXT;
      }
      else{
        $this->type = $type;
      }
    }

    public function getType():string{
      return $this->type;
    }
    public function getDefault():string{
      return $this->default;
    }
    public function getPlaceH():string{
      return $this->placeH;
    }
    public function type2string(string $type):string{
      switch($type){
        case "TYPE_TEXT":
          $type = "text";
          break;
        case "TYPE_PWD":
          $type = "password";
          break;
        default:
          $type = "text";
          break;
      }
      return $type;
    }

    public function __toString():string{
      return
      "
      <div class=\"form-group col-md-6\">
        <label for=\"pseudo\">Pseudo</label>
        <input name=\"pseudo\"  type=\"text\" class=\"form-control\" id=\"pseudo\" placeholer=\"Entrez votre pseudo\" required>
      </div>
      "
    }
  }
 ?>
