<?php
  class Form{
    private $id;
    private $action;
    private $mode;
    private static $fields=[];
    const MODE_GET = "get";
    const MODE_POST = "post";

  function __construct(string $id, string $action, string $mode){
    $this->id = $id;
    $this->action = $action;
    if(($mode!=self::MODE_GET)||($mode!=self::MODE_POST)){
      $this->mode=self::MODE_GET;
    }
    else{
      $this->mode=$mode;
    }
  }

  public function getId():string{
    return $this->id;
  }

  public function getAction():string{
    return $this->action;
  }

  public function getMode():string{
    return $this->mode;
  }

  public function __toString():string{
    return "
    <form id=\"".$this->getId()."\" method=\"".$this->getMode()."\" action=\"".$this->getAction()."\">
          <!--Div à remplacer par la création d'un field-->
      <div class=\"form-group col-md-6\">
        <label for=\"pseudo\">Pseudo</label>
        <input name=\"pseudo\"  type=\"text\" class=\"form-control\" id=\"pseudo\" placeholer=\"Entrez votre pseudo\" required>
      </div>
          <!--Div à remplacer par la création d'un field-->
      <div class=\"form-group col-md-6\">
        <label for=\"mdp\">Mot de passe</label>
        <input name=\"mdp\"  type=\"password\" class=\"form-control\" id=\"mdp\" required>
      </div>
      <button style=\"margin-left: 1em;\" type=\"submit\" class=\"btn btn-primary\" name=\"validerLog\">Valider</button>
    </form>
    ";
    }

  public function addField(FormField $ff):string{

  }
}
 ?>
